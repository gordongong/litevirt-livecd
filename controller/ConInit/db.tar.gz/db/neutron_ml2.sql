-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: neutron_ml2
-- ------------------------------------------------------
-- Server version	5.5.36-MariaDB-wsrep

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agents`
--

DROP TABLE IF EXISTS `agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agents` (
  `id` varchar(36) NOT NULL,
  `agent_type` varchar(255) NOT NULL,
  `binary` varchar(255) NOT NULL,
  `topic` varchar(255) NOT NULL,
  `host` varchar(255) NOT NULL,
  `admin_state_up` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `started_at` datetime NOT NULL,
  `heartbeat_timestamp` datetime NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `configurations` varchar(4095) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agents`
--

LOCK TABLES `agents` WRITE;
/*!40000 ALTER TABLE `agents` DISABLE KEYS */;
INSERT INTO `agents` VALUES ('11d24b0e-5383-4da4-9f55-3db407ead0e4','DHCP agent','neutron-dhcp-agent','dhcp_agent','controller',1,'2014-05-22 14:21:22','2014-05-22 14:22:16','2014-05-22 14:47:46',NULL,'{\"subnets\": 0, \"use_namespaces\": true, \"dhcp_lease_duration\": 86400, \"dhcp_driver\": \"neutron.agent.linux.dhcp.Dnsmasq\", \"networks\": 0, \"ports\": 0}'),('63ace9b1-8b9f-437b-b056-3a3ae227615a','L3 agent','neutron-l3-agent','l3_agent','controller',1,'2014-05-22 14:21:24','2014-05-22 14:22:18','2014-05-22 14:47:48',NULL,'{\"router_id\": \"\", \"gateway_external_network_id\": \"\", \"handle_internal_only_routers\": true, \"use_namespaces\": true, \"routers\": 0, \"interfaces\": 0, \"floating_ips\": 0, \"interface_driver\": \"neutron.agent.linux.interface.OVSInterfaceDriver\", \"ex_gw_ports\": 0}'),('81128fc9-123e-4155-bff6-8859d85e1709','Metadata agent','neutron-metadata-agent','N/A','controller',1,'2014-05-22 14:21:24','2014-05-22 14:21:24','2014-05-22 14:47:50',NULL,'{\"nova_metadata_ip\": \"192.168.1.104\", \"nova_metadata_port\": 8775, \"metadata_proxy_socket\": \"/var/lib/neutron/metadata_proxy\"}'),('a0d7b71a-98ea-40b6-9fca-c1f657d68e82','Open vSwitch agent','neutron-openvswitch-agent','N/A','controller',1,'2014-05-22 14:21:42','2014-05-22 14:21:42','2014-05-22 14:47:50',NULL,'{\"tunnel_types\": [], \"tunneling_ip\": \"\", \"bridge_mappings\": {}, \"l2_population\": false, \"devices\": 1}');
/*!40000 ALTER TABLE `agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('icehouse');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allowedaddresspairs`
--

DROP TABLE IF EXISTS `allowedaddresspairs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowedaddresspairs` (
  `port_id` varchar(36) NOT NULL,
  `mac_address` varchar(32) NOT NULL,
  `ip_address` varchar(64) NOT NULL,
  PRIMARY KEY (`port_id`,`mac_address`,`ip_address`),
  CONSTRAINT `allowedaddresspairs_ibfk_1` FOREIGN KEY (`port_id`) REFERENCES `ports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allowedaddresspairs`
--

LOCK TABLES `allowedaddresspairs` WRITE;
/*!40000 ALTER TABLE `allowedaddresspairs` DISABLE KEYS */;
/*!40000 ALTER TABLE `allowedaddresspairs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arista_provisioned_nets`
--

DROP TABLE IF EXISTS `arista_provisioned_nets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arista_provisioned_nets` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `network_id` varchar(36) DEFAULT NULL,
  `segmentation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arista_provisioned_nets`
--

LOCK TABLES `arista_provisioned_nets` WRITE;
/*!40000 ALTER TABLE `arista_provisioned_nets` DISABLE KEYS */;
/*!40000 ALTER TABLE `arista_provisioned_nets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arista_provisioned_tenants`
--

DROP TABLE IF EXISTS `arista_provisioned_tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arista_provisioned_tenants` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arista_provisioned_tenants`
--

LOCK TABLES `arista_provisioned_tenants` WRITE;
/*!40000 ALTER TABLE `arista_provisioned_tenants` DISABLE KEYS */;
/*!40000 ALTER TABLE `arista_provisioned_tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arista_provisioned_vms`
--

DROP TABLE IF EXISTS `arista_provisioned_vms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arista_provisioned_vms` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `vm_id` varchar(255) DEFAULT NULL,
  `host_id` varchar(255) DEFAULT NULL,
  `port_id` varchar(36) DEFAULT NULL,
  `network_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arista_provisioned_vms`
--

LOCK TABLES `arista_provisioned_vms` WRITE;
/*!40000 ALTER TABLE `arista_provisioned_vms` DISABLE KEYS */;
/*!40000 ALTER TABLE `arista_provisioned_vms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cisco_ml2_credentials`
--

DROP TABLE IF EXISTS `cisco_ml2_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cisco_ml2_credentials` (
  `credential_id` varchar(255) DEFAULT NULL,
  `tenant_id` varchar(255) NOT NULL,
  `credential_name` varchar(255) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tenant_id`,`credential_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cisco_ml2_credentials`
--

LOCK TABLES `cisco_ml2_credentials` WRITE;
/*!40000 ALTER TABLE `cisco_ml2_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `cisco_ml2_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cisco_ml2_nexusport_bindings`
--

DROP TABLE IF EXISTS `cisco_ml2_nexusport_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cisco_ml2_nexusport_bindings` (
  `binding_id` int(11) NOT NULL AUTO_INCREMENT,
  `port_id` varchar(255) DEFAULT NULL,
  `vlan_id` int(11) NOT NULL,
  `switch_ip` varchar(255) DEFAULT NULL,
  `instance_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`binding_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cisco_ml2_nexusport_bindings`
--

LOCK TABLES `cisco_ml2_nexusport_bindings` WRITE;
/*!40000 ALTER TABLE `cisco_ml2_nexusport_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `cisco_ml2_nexusport_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consistencyhashes`
--

DROP TABLE IF EXISTS `consistencyhashes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consistencyhashes` (
  `hash_id` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  PRIMARY KEY (`hash_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consistencyhashes`
--

LOCK TABLES `consistencyhashes` WRITE;
/*!40000 ALTER TABLE `consistencyhashes` DISABLE KEYS */;
/*!40000 ALTER TABLE `consistencyhashes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsnameservers`
--

DROP TABLE IF EXISTS `dnsnameservers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsnameservers` (
  `address` varchar(128) NOT NULL,
  `subnet_id` varchar(36) NOT NULL,
  PRIMARY KEY (`address`,`subnet_id`),
  KEY `subnet_id` (`subnet_id`),
  CONSTRAINT `dnsnameservers_ibfk_1` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsnameservers`
--

LOCK TABLES `dnsnameservers` WRITE;
/*!40000 ALTER TABLE `dnsnameservers` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnsnameservers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `externalnetworks`
--

DROP TABLE IF EXISTS `externalnetworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `externalnetworks` (
  `network_id` varchar(36) NOT NULL,
  PRIMARY KEY (`network_id`),
  CONSTRAINT `externalnetworks_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `externalnetworks`
--

LOCK TABLES `externalnetworks` WRITE;
/*!40000 ALTER TABLE `externalnetworks` DISABLE KEYS */;
/*!40000 ALTER TABLE `externalnetworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extradhcpopts`
--

DROP TABLE IF EXISTS `extradhcpopts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extradhcpopts` (
  `id` varchar(36) NOT NULL,
  `port_id` varchar(36) NOT NULL,
  `opt_name` varchar(64) NOT NULL,
  `opt_value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_portid_optname` (`port_id`,`opt_name`),
  CONSTRAINT `extradhcpopts_ibfk_1` FOREIGN KEY (`port_id`) REFERENCES `ports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extradhcpopts`
--

LOCK TABLES `extradhcpopts` WRITE;
/*!40000 ALTER TABLE `extradhcpopts` DISABLE KEYS */;
/*!40000 ALTER TABLE `extradhcpopts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `floatingips`
--

DROP TABLE IF EXISTS `floatingips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `floatingips` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `floating_ip_address` varchar(64) NOT NULL,
  `floating_network_id` varchar(36) NOT NULL,
  `floating_port_id` varchar(36) NOT NULL,
  `fixed_port_id` varchar(36) DEFAULT NULL,
  `fixed_ip_address` varchar(64) DEFAULT NULL,
  `router_id` varchar(36) DEFAULT NULL,
  `last_known_router_id` varchar(36) DEFAULT NULL,
  `status` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fixed_port_id` (`fixed_port_id`),
  KEY `floating_port_id` (`floating_port_id`),
  KEY `router_id` (`router_id`),
  CONSTRAINT `floatingips_ibfk_1` FOREIGN KEY (`fixed_port_id`) REFERENCES `ports` (`id`),
  CONSTRAINT `floatingips_ibfk_2` FOREIGN KEY (`floating_port_id`) REFERENCES `ports` (`id`),
  CONSTRAINT `floatingips_ibfk_3` FOREIGN KEY (`router_id`) REFERENCES `routers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `floatingips`
--

LOCK TABLES `floatingips` WRITE;
/*!40000 ALTER TABLE `floatingips` DISABLE KEYS */;
/*!40000 ALTER TABLE `floatingips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipallocationpools`
--

DROP TABLE IF EXISTS `ipallocationpools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipallocationpools` (
  `id` varchar(36) NOT NULL,
  `subnet_id` varchar(36) DEFAULT NULL,
  `first_ip` varchar(64) NOT NULL,
  `last_ip` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subnet_id` (`subnet_id`),
  CONSTRAINT `ipallocationpools_ibfk_1` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipallocationpools`
--

LOCK TABLES `ipallocationpools` WRITE;
/*!40000 ALTER TABLE `ipallocationpools` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipallocationpools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipallocations`
--

DROP TABLE IF EXISTS `ipallocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipallocations` (
  `port_id` varchar(36) DEFAULT NULL,
  `ip_address` varchar(64) NOT NULL,
  `subnet_id` varchar(36) NOT NULL,
  `network_id` varchar(36) NOT NULL,
  PRIMARY KEY (`ip_address`,`subnet_id`,`network_id`),
  KEY `network_id` (`network_id`),
  KEY `port_id` (`port_id`),
  KEY `subnet_id` (`subnet_id`),
  CONSTRAINT `ipallocations_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ipallocations_ibfk_2` FOREIGN KEY (`port_id`) REFERENCES `ports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ipallocations_ibfk_3` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipallocations`
--

LOCK TABLES `ipallocations` WRITE;
/*!40000 ALTER TABLE `ipallocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipallocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipavailabilityranges`
--

DROP TABLE IF EXISTS `ipavailabilityranges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipavailabilityranges` (
  `allocation_pool_id` varchar(36) NOT NULL,
  `first_ip` varchar(64) NOT NULL,
  `last_ip` varchar(64) NOT NULL,
  PRIMARY KEY (`allocation_pool_id`,`first_ip`,`last_ip`),
  CONSTRAINT `ipavailabilityranges_ibfk_1` FOREIGN KEY (`allocation_pool_id`) REFERENCES `ipallocationpools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipavailabilityranges`
--

LOCK TABLES `ipavailabilityranges` WRITE;
/*!40000 ALTER TABLE `ipavailabilityranges` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipavailabilityranges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_brocadenetworks`
--

DROP TABLE IF EXISTS `ml2_brocadenetworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_brocadenetworks` (
  `id` varchar(36) NOT NULL,
  `vlan` varchar(10) DEFAULT NULL,
  `segment_id` varchar(36) DEFAULT NULL,
  `network_type` varchar(10) DEFAULT NULL,
  `tenant_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_brocadenetworks`
--

LOCK TABLES `ml2_brocadenetworks` WRITE;
/*!40000 ALTER TABLE `ml2_brocadenetworks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_brocadenetworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_brocadeports`
--

DROP TABLE IF EXISTS `ml2_brocadeports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_brocadeports` (
  `id` varchar(36) NOT NULL,
  `network_id` varchar(36) NOT NULL,
  `admin_state_up` tinyint(1) DEFAULT NULL,
  `physical_interface` varchar(36) DEFAULT NULL,
  `vlan_id` varchar(36) DEFAULT NULL,
  `tenant_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_brocadeports`
--

LOCK TABLES `ml2_brocadeports` WRITE;
/*!40000 ALTER TABLE `ml2_brocadeports` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_brocadeports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_flat_allocations`
--

DROP TABLE IF EXISTS `ml2_flat_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_flat_allocations` (
  `physical_network` varchar(64) NOT NULL,
  PRIMARY KEY (`physical_network`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_flat_allocations`
--

LOCK TABLES `ml2_flat_allocations` WRITE;
/*!40000 ALTER TABLE `ml2_flat_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_flat_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_gre_allocations`
--

DROP TABLE IF EXISTS `ml2_gre_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_gre_allocations` (
  `gre_id` int(11) NOT NULL,
  `allocated` tinyint(1) NOT NULL,
  PRIMARY KEY (`gre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_gre_allocations`
--

LOCK TABLES `ml2_gre_allocations` WRITE;
/*!40000 ALTER TABLE `ml2_gre_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_gre_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_gre_endpoints`
--

DROP TABLE IF EXISTS `ml2_gre_endpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_gre_endpoints` (
  `ip_address` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_gre_endpoints`
--

LOCK TABLES `ml2_gre_endpoints` WRITE;
/*!40000 ALTER TABLE `ml2_gre_endpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_gre_endpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_network_segments`
--

DROP TABLE IF EXISTS `ml2_network_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_network_segments` (
  `id` varchar(36) NOT NULL,
  `network_id` varchar(36) NOT NULL,
  `network_type` varchar(32) NOT NULL,
  `physical_network` varchar(64) DEFAULT NULL,
  `segmentation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_id` (`network_id`),
  CONSTRAINT `ml2_network_segments_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_network_segments`
--

LOCK TABLES `ml2_network_segments` WRITE;
/*!40000 ALTER TABLE `ml2_network_segments` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_network_segments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_port_bindings`
--

DROP TABLE IF EXISTS `ml2_port_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_port_bindings` (
  `port_id` varchar(36) NOT NULL,
  `host` varchar(255) NOT NULL,
  `vif_type` varchar(64) NOT NULL,
  `driver` varchar(64) DEFAULT NULL,
  `segment` varchar(36) DEFAULT NULL,
  `vnic_type` varchar(64) NOT NULL DEFAULT 'normal',
  `vif_details` varchar(4095) NOT NULL DEFAULT '',
  `profile` varchar(4095) NOT NULL DEFAULT '',
  PRIMARY KEY (`port_id`),
  KEY `segment` (`segment`),
  CONSTRAINT `ml2_port_bindings_ibfk_1` FOREIGN KEY (`port_id`) REFERENCES `ports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ml2_port_bindings_ibfk_2` FOREIGN KEY (`segment`) REFERENCES `ml2_network_segments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_port_bindings`
--

LOCK TABLES `ml2_port_bindings` WRITE;
/*!40000 ALTER TABLE `ml2_port_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_port_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_vlan_allocations`
--

DROP TABLE IF EXISTS `ml2_vlan_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_vlan_allocations` (
  `physical_network` varchar(64) NOT NULL,
  `vlan_id` int(11) NOT NULL,
  `allocated` tinyint(1) NOT NULL,
  PRIMARY KEY (`physical_network`,`vlan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_vlan_allocations`
--

LOCK TABLES `ml2_vlan_allocations` WRITE;
/*!40000 ALTER TABLE `ml2_vlan_allocations` DISABLE KEYS */;
INSERT INTO `ml2_vlan_allocations` VALUES ('physnet1',1,0),('physnet1',2,0),('physnet1',3,0),('physnet1',4,0),('physnet1',5,0),('physnet1',6,0),('physnet1',7,0),('physnet1',8,0),('physnet1',9,0),('physnet1',10,0),('physnet1',11,0),('physnet1',12,0),('physnet1',13,0),('physnet1',14,0),('physnet1',15,0),('physnet1',16,0),('physnet1',17,0),('physnet1',18,0),('physnet1',19,0),('physnet1',20,0),('physnet1',21,0),('physnet1',22,0),('physnet1',23,0),('physnet1',24,0),('physnet1',25,0),('physnet1',26,0),('physnet1',27,0),('physnet1',28,0),('physnet1',29,0),('physnet1',30,0),('physnet1',31,0),('physnet1',32,0),('physnet1',33,0),('physnet1',34,0),('physnet1',35,0),('physnet1',36,0),('physnet1',37,0),('physnet1',38,0),('physnet1',39,0),('physnet1',40,0),('physnet1',41,0),('physnet1',42,0),('physnet1',43,0),('physnet1',44,0),('physnet1',45,0),('physnet1',46,0),('physnet1',47,0),('physnet1',48,0),('physnet1',49,0),('physnet1',50,0),('physnet1',51,0),('physnet1',52,0),('physnet1',53,0),('physnet1',54,0),('physnet1',55,0),('physnet1',56,0),('physnet1',57,0),('physnet1',58,0),('physnet1',59,0),('physnet1',60,0),('physnet1',61,0),('physnet1',62,0),('physnet1',63,0),('physnet1',64,0),('physnet1',65,0),('physnet1',66,0),('physnet1',67,0),('physnet1',68,0),('physnet1',69,0),('physnet1',70,0),('physnet1',71,0),('physnet1',72,0),('physnet1',73,0),('physnet1',74,0),('physnet1',75,0),('physnet1',76,0),('physnet1',77,0),('physnet1',78,0),('physnet1',79,0),('physnet1',80,0),('physnet1',81,0),('physnet1',82,0),('physnet1',83,0),('physnet1',84,0),('physnet1',85,0),('physnet1',86,0),('physnet1',87,0),('physnet1',88,0),('physnet1',89,0),('physnet1',90,0),('physnet1',91,0),('physnet1',92,0),('physnet1',93,0),('physnet1',94,0),('physnet1',95,0),('physnet1',96,0),('physnet1',97,0),('physnet1',98,0),('physnet1',99,0),('physnet1',100,0),('physnet1',101,0),('physnet1',102,0),('physnet1',103,0),('physnet1',104,0),('physnet1',105,0),('physnet1',106,0),('physnet1',107,0),('physnet1',108,0),('physnet1',109,0),('physnet1',110,0),('physnet1',111,0),('physnet1',112,0),('physnet1',113,0),('physnet1',114,0),('physnet1',115,0),('physnet1',116,0),('physnet1',117,0),('physnet1',118,0),('physnet1',119,0),('physnet1',120,0),('physnet1',121,0),('physnet1',122,0),('physnet1',123,0),('physnet1',124,0),('physnet1',125,0),('physnet1',126,0),('physnet1',127,0),('physnet1',128,0),('physnet1',129,0),('physnet1',130,0),('physnet1',131,0),('physnet1',132,0),('physnet1',133,0),('physnet1',134,0),('physnet1',135,0),('physnet1',136,0),('physnet1',137,0),('physnet1',138,0),('physnet1',139,0),('physnet1',140,0),('physnet1',141,0),('physnet1',142,0),('physnet1',143,0),('physnet1',144,0),('physnet1',145,0),('physnet1',146,0),('physnet1',147,0),('physnet1',148,0),('physnet1',149,0),('physnet1',150,0),('physnet1',151,0),('physnet1',152,0),('physnet1',153,0),('physnet1',154,0),('physnet1',155,0),('physnet1',156,0),('physnet1',157,0),('physnet1',158,0),('physnet1',159,0),('physnet1',160,0),('physnet1',161,0),('physnet1',162,0),('physnet1',163,0),('physnet1',164,0),('physnet1',165,0),('physnet1',166,0),('physnet1',167,0),('physnet1',168,0),('physnet1',169,0),('physnet1',170,0),('physnet1',171,0),('physnet1',172,0),('physnet1',173,0),('physnet1',174,0),('physnet1',175,0),('physnet1',176,0),('physnet1',177,0),('physnet1',178,0),('physnet1',179,0),('physnet1',180,0),('physnet1',181,0),('physnet1',182,0),('physnet1',183,0),('physnet1',184,0),('physnet1',185,0),('physnet1',186,0),('physnet1',187,0),('physnet1',188,0),('physnet1',189,0),('physnet1',190,0),('physnet1',191,0),('physnet1',192,0),('physnet1',193,0),('physnet1',194,0),('physnet1',195,0),('physnet1',196,0),('physnet1',197,0),('physnet1',198,0),('physnet1',199,0),('physnet1',200,0),('physnet1',201,0),('physnet1',202,0),('physnet1',203,0),('physnet1',204,0),('physnet1',205,0),('physnet1',206,0),('physnet1',207,0),('physnet1',208,0),('physnet1',209,0),('physnet1',210,0),('physnet1',211,0),('physnet1',212,0),('physnet1',213,0),('physnet1',214,0),('physnet1',215,0),('physnet1',216,0),('physnet1',217,0),('physnet1',218,0),('physnet1',219,0),('physnet1',220,0),('physnet1',221,0),('physnet1',222,0),('physnet1',223,0),('physnet1',224,0),('physnet1',225,0),('physnet1',226,0),('physnet1',227,0),('physnet1',228,0),('physnet1',229,0),('physnet1',230,0),('physnet1',231,0),('physnet1',232,0),('physnet1',233,0),('physnet1',234,0),('physnet1',235,0),('physnet1',236,0),('physnet1',237,0),('physnet1',238,0),('physnet1',239,0),('physnet1',240,0),('physnet1',241,0),('physnet1',242,0),('physnet1',243,0),('physnet1',244,0),('physnet1',245,0),('physnet1',246,0),('physnet1',247,0),('physnet1',248,0),('physnet1',249,0),('physnet1',250,0),('physnet1',251,0),('physnet1',252,0),('physnet1',253,0),('physnet1',254,0),('physnet1',255,0),('physnet1',256,0),('physnet1',257,0),('physnet1',258,0),('physnet1',259,0),('physnet1',260,0),('physnet1',261,0),('physnet1',262,0),('physnet1',263,0),('physnet1',264,0),('physnet1',265,0),('physnet1',266,0),('physnet1',267,0),('physnet1',268,0),('physnet1',269,0),('physnet1',270,0),('physnet1',271,0),('physnet1',272,0),('physnet1',273,0),('physnet1',274,0),('physnet1',275,0),('physnet1',276,0),('physnet1',277,0),('physnet1',278,0),('physnet1',279,0),('physnet1',280,0),('physnet1',281,0),('physnet1',282,0),('physnet1',283,0),('physnet1',284,0),('physnet1',285,0),('physnet1',286,0),('physnet1',287,0),('physnet1',288,0),('physnet1',289,0),('physnet1',290,0),('physnet1',291,0),('physnet1',292,0),('physnet1',293,0),('physnet1',294,0),('physnet1',295,0),('physnet1',296,0),('physnet1',297,0),('physnet1',298,0),('physnet1',299,0),('physnet1',300,0),('physnet1',301,0),('physnet1',302,0),('physnet1',303,0),('physnet1',304,0),('physnet1',305,0),('physnet1',306,0),('physnet1',307,0),('physnet1',308,0),('physnet1',309,0),('physnet1',310,0),('physnet1',311,0),('physnet1',312,0),('physnet1',313,0),('physnet1',314,0),('physnet1',315,0),('physnet1',316,0),('physnet1',317,0),('physnet1',318,0),('physnet1',319,0),('physnet1',320,0),('physnet1',321,0),('physnet1',322,0),('physnet1',323,0),('physnet1',324,0),('physnet1',325,0),('physnet1',326,0),('physnet1',327,0),('physnet1',328,0),('physnet1',329,0),('physnet1',330,0),('physnet1',331,0),('physnet1',332,0),('physnet1',333,0),('physnet1',334,0),('physnet1',335,0),('physnet1',336,0),('physnet1',337,0),('physnet1',338,0),('physnet1',339,0),('physnet1',340,0),('physnet1',341,0),('physnet1',342,0),('physnet1',343,0),('physnet1',344,0),('physnet1',345,0),('physnet1',346,0),('physnet1',347,0),('physnet1',348,0),('physnet1',349,0),('physnet1',350,0),('physnet1',351,0),('physnet1',352,0),('physnet1',353,0),('physnet1',354,0),('physnet1',355,0),('physnet1',356,0),('physnet1',357,0),('physnet1',358,0),('physnet1',359,0),('physnet1',360,0),('physnet1',361,0),('physnet1',362,0),('physnet1',363,0),('physnet1',364,0),('physnet1',365,0),('physnet1',366,0),('physnet1',367,0),('physnet1',368,0),('physnet1',369,0),('physnet1',370,0),('physnet1',371,0),('physnet1',372,0),('physnet1',373,0),('physnet1',374,0),('physnet1',375,0),('physnet1',376,0),('physnet1',377,0),('physnet1',378,0),('physnet1',379,0),('physnet1',380,0),('physnet1',381,0),('physnet1',382,0),('physnet1',383,0),('physnet1',384,0),('physnet1',385,0),('physnet1',386,0),('physnet1',387,0),('physnet1',388,0),('physnet1',389,0),('physnet1',390,0),('physnet1',391,0),('physnet1',392,0),('physnet1',393,0),('physnet1',394,0),('physnet1',395,0),('physnet1',396,0),('physnet1',397,0),('physnet1',398,0),('physnet1',399,0),('physnet1',400,0),('physnet1',401,0),('physnet1',402,0),('physnet1',403,0),('physnet1',404,0),('physnet1',405,0),('physnet1',406,0),('physnet1',407,0),('physnet1',408,0),('physnet1',409,0),('physnet1',410,0),('physnet1',411,0),('physnet1',412,0),('physnet1',413,0),('physnet1',414,0),('physnet1',415,0),('physnet1',416,0),('physnet1',417,0),('physnet1',418,0),('physnet1',419,0),('physnet1',420,0),('physnet1',421,0),('physnet1',422,0),('physnet1',423,0),('physnet1',424,0),('physnet1',425,0),('physnet1',426,0),('physnet1',427,0),('physnet1',428,0),('physnet1',429,0),('physnet1',430,0),('physnet1',431,0),('physnet1',432,0),('physnet1',433,0),('physnet1',434,0),('physnet1',435,0),('physnet1',436,0),('physnet1',437,0),('physnet1',438,0),('physnet1',439,0),('physnet1',440,0),('physnet1',441,0),('physnet1',442,0),('physnet1',443,0),('physnet1',444,0),('physnet1',445,0),('physnet1',446,0),('physnet1',447,0),('physnet1',448,0),('physnet1',449,0),('physnet1',450,0),('physnet1',451,0),('physnet1',452,0),('physnet1',453,0),('physnet1',454,0),('physnet1',455,0),('physnet1',456,0),('physnet1',457,0),('physnet1',458,0),('physnet1',459,0),('physnet1',460,0),('physnet1',461,0),('physnet1',462,0),('physnet1',463,0),('physnet1',464,0),('physnet1',465,0),('physnet1',466,0),('physnet1',467,0),('physnet1',468,0),('physnet1',469,0),('physnet1',470,0),('physnet1',471,0),('physnet1',472,0),('physnet1',473,0),('physnet1',474,0),('physnet1',475,0),('physnet1',476,0),('physnet1',477,0),('physnet1',478,0),('physnet1',479,0),('physnet1',480,0),('physnet1',481,0),('physnet1',482,0),('physnet1',483,0),('physnet1',484,0),('physnet1',485,0),('physnet1',486,0),('physnet1',487,0),('physnet1',488,0),('physnet1',489,0),('physnet1',490,0),('physnet1',491,0),('physnet1',492,0),('physnet1',493,0),('physnet1',494,0),('physnet1',495,0),('physnet1',496,0),('physnet1',497,0),('physnet1',498,0),('physnet1',499,0),('physnet1',500,0),('physnet1',501,0),('physnet1',502,0),('physnet1',503,0),('physnet1',504,0),('physnet1',505,0),('physnet1',506,0),('physnet1',507,0),('physnet1',508,0),('physnet1',509,0),('physnet1',510,0),('physnet1',511,0),('physnet1',512,0),('physnet1',513,0),('physnet1',514,0),('physnet1',515,0),('physnet1',516,0),('physnet1',517,0),('physnet1',518,0),('physnet1',519,0),('physnet1',520,0),('physnet1',521,0),('physnet1',522,0),('physnet1',523,0),('physnet1',524,0),('physnet1',525,0),('physnet1',526,0),('physnet1',527,0),('physnet1',528,0),('physnet1',529,0),('physnet1',530,0),('physnet1',531,0),('physnet1',532,0),('physnet1',533,0),('physnet1',534,0),('physnet1',535,0),('physnet1',536,0),('physnet1',537,0),('physnet1',538,0),('physnet1',539,0),('physnet1',540,0),('physnet1',541,0),('physnet1',542,0),('physnet1',543,0),('physnet1',544,0),('physnet1',545,0),('physnet1',546,0),('physnet1',547,0),('physnet1',548,0),('physnet1',549,0),('physnet1',550,0),('physnet1',551,0),('physnet1',552,0),('physnet1',553,0),('physnet1',554,0),('physnet1',555,0),('physnet1',556,0),('physnet1',557,0),('physnet1',558,0),('physnet1',559,0),('physnet1',560,0),('physnet1',561,0),('physnet1',562,0),('physnet1',563,0),('physnet1',564,0),('physnet1',565,0),('physnet1',566,0),('physnet1',567,0),('physnet1',568,0),('physnet1',569,0),('physnet1',570,0),('physnet1',571,0),('physnet1',572,0),('physnet1',573,0),('physnet1',574,0),('physnet1',575,0),('physnet1',576,0),('physnet1',577,0),('physnet1',578,0),('physnet1',579,0),('physnet1',580,0),('physnet1',581,0),('physnet1',582,0),('physnet1',583,0),('physnet1',584,0),('physnet1',585,0),('physnet1',586,0),('physnet1',587,0),('physnet1',588,0),('physnet1',589,0),('physnet1',590,0),('physnet1',591,0),('physnet1',592,0),('physnet1',593,0),('physnet1',594,0),('physnet1',595,0),('physnet1',596,0),('physnet1',597,0),('physnet1',598,0),('physnet1',599,0),('physnet1',600,0),('physnet1',601,0),('physnet1',602,0),('physnet1',603,0),('physnet1',604,0),('physnet1',605,0),('physnet1',606,0),('physnet1',607,0),('physnet1',608,0),('physnet1',609,0),('physnet1',610,0),('physnet1',611,0),('physnet1',612,0),('physnet1',613,0),('physnet1',614,0),('physnet1',615,0),('physnet1',616,0),('physnet1',617,0),('physnet1',618,0),('physnet1',619,0),('physnet1',620,0),('physnet1',621,0),('physnet1',622,0),('physnet1',623,0),('physnet1',624,0),('physnet1',625,0),('physnet1',626,0),('physnet1',627,0),('physnet1',628,0),('physnet1',629,0),('physnet1',630,0),('physnet1',631,0),('physnet1',632,0),('physnet1',633,0),('physnet1',634,0),('physnet1',635,0),('physnet1',636,0),('physnet1',637,0),('physnet1',638,0),('physnet1',639,0),('physnet1',640,0),('physnet1',641,0),('physnet1',642,0),('physnet1',643,0),('physnet1',644,0),('physnet1',645,0),('physnet1',646,0),('physnet1',647,0),('physnet1',648,0),('physnet1',649,0),('physnet1',650,0),('physnet1',651,0),('physnet1',652,0),('physnet1',653,0),('physnet1',654,0),('physnet1',655,0),('physnet1',656,0),('physnet1',657,0),('physnet1',658,0),('physnet1',659,0),('physnet1',660,0),('physnet1',661,0),('physnet1',662,0),('physnet1',663,0),('physnet1',664,0),('physnet1',665,0),('physnet1',666,0),('physnet1',667,0),('physnet1',668,0),('physnet1',669,0),('physnet1',670,0),('physnet1',671,0),('physnet1',672,0),('physnet1',673,0),('physnet1',674,0),('physnet1',675,0),('physnet1',676,0),('physnet1',677,0),('physnet1',678,0),('physnet1',679,0),('physnet1',680,0),('physnet1',681,0),('physnet1',682,0),('physnet1',683,0),('physnet1',684,0),('physnet1',685,0),('physnet1',686,0),('physnet1',687,0),('physnet1',688,0),('physnet1',689,0),('physnet1',690,0),('physnet1',691,0),('physnet1',692,0),('physnet1',693,0),('physnet1',694,0),('physnet1',695,0),('physnet1',696,0),('physnet1',697,0),('physnet1',698,0),('physnet1',699,0),('physnet1',700,0),('physnet1',701,0),('physnet1',702,0),('physnet1',703,0),('physnet1',704,0),('physnet1',705,0),('physnet1',706,0),('physnet1',707,0),('physnet1',708,0),('physnet1',709,0),('physnet1',710,0),('physnet1',711,0),('physnet1',712,0),('physnet1',713,0),('physnet1',714,0),('physnet1',715,0),('physnet1',716,0),('physnet1',717,0),('physnet1',718,0),('physnet1',719,0),('physnet1',720,0),('physnet1',721,0),('physnet1',722,0),('physnet1',723,0),('physnet1',724,0),('physnet1',725,0),('physnet1',726,0),('physnet1',727,0),('physnet1',728,0),('physnet1',729,0),('physnet1',730,0),('physnet1',731,0),('physnet1',732,0),('physnet1',733,0),('physnet1',734,0),('physnet1',735,0),('physnet1',736,0),('physnet1',737,0),('physnet1',738,0),('physnet1',739,0),('physnet1',740,0),('physnet1',741,0),('physnet1',742,0),('physnet1',743,0),('physnet1',744,0),('physnet1',745,0),('physnet1',746,0),('physnet1',747,0),('physnet1',748,0),('physnet1',749,0),('physnet1',750,0),('physnet1',751,0),('physnet1',752,0),('physnet1',753,0),('physnet1',754,0),('physnet1',755,0),('physnet1',756,0),('physnet1',757,0),('physnet1',758,0),('physnet1',759,0),('physnet1',760,0),('physnet1',761,0),('physnet1',762,0),('physnet1',763,0),('physnet1',764,0),('physnet1',765,0),('physnet1',766,0),('physnet1',767,0),('physnet1',768,0),('physnet1',769,0),('physnet1',770,0),('physnet1',771,0),('physnet1',772,0),('physnet1',773,0),('physnet1',774,0),('physnet1',775,0),('physnet1',776,0),('physnet1',777,0),('physnet1',778,0),('physnet1',779,0),('physnet1',780,0),('physnet1',781,0),('physnet1',782,0),('physnet1',783,0),('physnet1',784,0),('physnet1',785,0),('physnet1',786,0),('physnet1',787,0),('physnet1',788,0),('physnet1',789,0),('physnet1',790,0),('physnet1',791,0),('physnet1',792,0),('physnet1',793,0),('physnet1',794,0),('physnet1',795,0),('physnet1',796,0),('physnet1',797,0),('physnet1',798,0),('physnet1',799,0),('physnet1',800,0),('physnet1',801,0),('physnet1',802,0),('physnet1',803,0),('physnet1',804,0),('physnet1',805,0),('physnet1',806,0),('physnet1',807,0),('physnet1',808,0),('physnet1',809,0),('physnet1',810,0),('physnet1',811,0),('physnet1',812,0),('physnet1',813,0),('physnet1',814,0),('physnet1',815,0),('physnet1',816,0),('physnet1',817,0),('physnet1',818,0),('physnet1',819,0),('physnet1',820,0),('physnet1',821,0),('physnet1',822,0),('physnet1',823,0),('physnet1',824,0),('physnet1',825,0),('physnet1',826,0),('physnet1',827,0),('physnet1',828,0),('physnet1',829,0),('physnet1',830,0),('physnet1',831,0),('physnet1',832,0),('physnet1',833,0),('physnet1',834,0),('physnet1',835,0),('physnet1',836,0),('physnet1',837,0),('physnet1',838,0),('physnet1',839,0),('physnet1',840,0),('physnet1',841,0),('physnet1',842,0),('physnet1',843,0),('physnet1',844,0),('physnet1',845,0),('physnet1',846,0),('physnet1',847,0),('physnet1',848,0),('physnet1',849,0),('physnet1',850,0),('physnet1',851,0),('physnet1',852,0),('physnet1',853,0),('physnet1',854,0),('physnet1',855,0),('physnet1',856,0),('physnet1',857,0),('physnet1',858,0),('physnet1',859,0),('physnet1',860,0),('physnet1',861,0),('physnet1',862,0),('physnet1',863,0),('physnet1',864,0),('physnet1',865,0),('physnet1',866,0),('physnet1',867,0),('physnet1',868,0),('physnet1',869,0),('physnet1',870,0),('physnet1',871,0),('physnet1',872,0),('physnet1',873,0),('physnet1',874,0),('physnet1',875,0),('physnet1',876,0),('physnet1',877,0),('physnet1',878,0),('physnet1',879,0),('physnet1',880,0),('physnet1',881,0),('physnet1',882,0),('physnet1',883,0),('physnet1',884,0),('physnet1',885,0),('physnet1',886,0),('physnet1',887,0),('physnet1',888,0),('physnet1',889,0),('physnet1',890,0),('physnet1',891,0),('physnet1',892,0),('physnet1',893,0),('physnet1',894,0),('physnet1',895,0),('physnet1',896,0),('physnet1',897,0),('physnet1',898,0),('physnet1',899,0),('physnet1',900,0),('physnet1',901,0),('physnet1',902,0),('physnet1',903,0),('physnet1',904,0),('physnet1',905,0),('physnet1',906,0),('physnet1',907,0),('physnet1',908,0),('physnet1',909,0),('physnet1',910,0),('physnet1',911,0),('physnet1',912,0),('physnet1',913,0),('physnet1',914,0),('physnet1',915,0),('physnet1',916,0),('physnet1',917,0),('physnet1',918,0),('physnet1',919,0),('physnet1',920,0),('physnet1',921,0),('physnet1',922,0),('physnet1',923,0),('physnet1',924,0),('physnet1',925,0),('physnet1',926,0),('physnet1',927,0),('physnet1',928,0),('physnet1',929,0),('physnet1',930,0),('physnet1',931,0),('physnet1',932,0),('physnet1',933,0),('physnet1',934,0),('physnet1',935,0),('physnet1',936,0),('physnet1',937,0),('physnet1',938,0),('physnet1',939,0),('physnet1',940,0),('physnet1',941,0),('physnet1',942,0),('physnet1',943,0),('physnet1',944,0),('physnet1',945,0),('physnet1',946,0),('physnet1',947,0),('physnet1',948,0),('physnet1',949,0),('physnet1',950,0),('physnet1',951,0),('physnet1',952,0),('physnet1',953,0),('physnet1',954,0),('physnet1',955,0),('physnet1',956,0),('physnet1',957,0),('physnet1',958,0),('physnet1',959,0),('physnet1',960,0),('physnet1',961,0),('physnet1',962,0),('physnet1',963,0),('physnet1',964,0),('physnet1',965,0),('physnet1',966,0),('physnet1',967,0),('physnet1',968,0),('physnet1',969,0),('physnet1',970,0),('physnet1',971,0),('physnet1',972,0),('physnet1',973,0),('physnet1',974,0),('physnet1',975,0),('physnet1',976,0),('physnet1',977,0),('physnet1',978,0),('physnet1',979,0),('physnet1',980,0),('physnet1',981,0),('physnet1',982,0),('physnet1',983,0),('physnet1',984,0),('physnet1',985,0),('physnet1',986,0),('physnet1',987,0),('physnet1',988,0),('physnet1',989,0),('physnet1',990,0),('physnet1',991,0),('physnet1',992,0),('physnet1',993,0),('physnet1',994,0),('physnet1',995,0),('physnet1',996,0),('physnet1',997,0),('physnet1',998,0),('physnet1',999,0),('physnet1',1000,0),('physnet1',1001,0),('physnet1',1002,0),('physnet1',1003,0),('physnet1',1004,0),('physnet1',1005,0),('physnet1',1006,0),('physnet1',1007,0),('physnet1',1008,0),('physnet1',1009,0),('physnet1',1010,0),('physnet1',1011,0),('physnet1',1012,0),('physnet1',1013,0),('physnet1',1014,0),('physnet1',1015,0),('physnet1',1016,0),('physnet1',1017,0),('physnet1',1018,0),('physnet1',1019,0),('physnet1',1020,0),('physnet1',1021,0),('physnet1',1022,0),('physnet1',1023,0),('physnet1',1024,0),('physnet1',1025,0),('physnet1',1026,0),('physnet1',1027,0),('physnet1',1028,0),('physnet1',1029,0),('physnet1',1030,0),('physnet1',1031,0),('physnet1',1032,0),('physnet1',1033,0),('physnet1',1034,0),('physnet1',1035,0),('physnet1',1036,0),('physnet1',1037,0),('physnet1',1038,0),('physnet1',1039,0),('physnet1',1040,0),('physnet1',1041,0),('physnet1',1042,0),('physnet1',1043,0),('physnet1',1044,0),('physnet1',1045,0),('physnet1',1046,0),('physnet1',1047,0),('physnet1',1048,0),('physnet1',1049,0),('physnet1',1050,0),('physnet1',1051,0),('physnet1',1052,0),('physnet1',1053,0),('physnet1',1054,0),('physnet1',1055,0),('physnet1',1056,0),('physnet1',1057,0),('physnet1',1058,0),('physnet1',1059,0),('physnet1',1060,0),('physnet1',1061,0),('physnet1',1062,0),('physnet1',1063,0),('physnet1',1064,0),('physnet1',1065,0),('physnet1',1066,0),('physnet1',1067,0),('physnet1',1068,0),('physnet1',1069,0),('physnet1',1070,0),('physnet1',1071,0),('physnet1',1072,0),('physnet1',1073,0),('physnet1',1074,0),('physnet1',1075,0),('physnet1',1076,0),('physnet1',1077,0),('physnet1',1078,0),('physnet1',1079,0),('physnet1',1080,0),('physnet1',1081,0),('physnet1',1082,0),('physnet1',1083,0),('physnet1',1084,0),('physnet1',1085,0),('physnet1',1086,0),('physnet1',1087,0),('physnet1',1088,0),('physnet1',1089,0),('physnet1',1090,0),('physnet1',1091,0),('physnet1',1092,0),('physnet1',1093,0),('physnet1',1094,0),('physnet1',1095,0),('physnet1',1096,0),('physnet1',1097,0),('physnet1',1098,0),('physnet1',1099,0),('physnet1',1100,0),('physnet1',1101,0),('physnet1',1102,0),('physnet1',1103,0),('physnet1',1104,0),('physnet1',1105,0),('physnet1',1106,0),('physnet1',1107,0),('physnet1',1108,0),('physnet1',1109,0),('physnet1',1110,0),('physnet1',1111,0),('physnet1',1112,0),('physnet1',1113,0),('physnet1',1114,0),('physnet1',1115,0),('physnet1',1116,0),('physnet1',1117,0),('physnet1',1118,0),('physnet1',1119,0),('physnet1',1120,0),('physnet1',1121,0),('physnet1',1122,0),('physnet1',1123,0),('physnet1',1124,0),('physnet1',1125,0),('physnet1',1126,0),('physnet1',1127,0),('physnet1',1128,0),('physnet1',1129,0),('physnet1',1130,0),('physnet1',1131,0),('physnet1',1132,0),('physnet1',1133,0),('physnet1',1134,0),('physnet1',1135,0),('physnet1',1136,0),('physnet1',1137,0),('physnet1',1138,0),('physnet1',1139,0),('physnet1',1140,0),('physnet1',1141,0),('physnet1',1142,0),('physnet1',1143,0),('physnet1',1144,0),('physnet1',1145,0),('physnet1',1146,0),('physnet1',1147,0),('physnet1',1148,0),('physnet1',1149,0),('physnet1',1150,0),('physnet1',1151,0),('physnet1',1152,0),('physnet1',1153,0),('physnet1',1154,0),('physnet1',1155,0),('physnet1',1156,0),('physnet1',1157,0),('physnet1',1158,0),('physnet1',1159,0),('physnet1',1160,0),('physnet1',1161,0),('physnet1',1162,0),('physnet1',1163,0),('physnet1',1164,0),('physnet1',1165,0),('physnet1',1166,0),('physnet1',1167,0),('physnet1',1168,0),('physnet1',1169,0),('physnet1',1170,0),('physnet1',1171,0),('physnet1',1172,0),('physnet1',1173,0),('physnet1',1174,0),('physnet1',1175,0),('physnet1',1176,0),('physnet1',1177,0),('physnet1',1178,0),('physnet1',1179,0),('physnet1',1180,0),('physnet1',1181,0),('physnet1',1182,0),('physnet1',1183,0),('physnet1',1184,0),('physnet1',1185,0),('physnet1',1186,0),('physnet1',1187,0),('physnet1',1188,0),('physnet1',1189,0),('physnet1',1190,0),('physnet1',1191,0),('physnet1',1192,0),('physnet1',1193,0),('physnet1',1194,0),('physnet1',1195,0),('physnet1',1196,0),('physnet1',1197,0),('physnet1',1198,0),('physnet1',1199,0),('physnet1',1200,0),('physnet1',1201,0),('physnet1',1202,0),('physnet1',1203,0),('physnet1',1204,0),('physnet1',1205,0),('physnet1',1206,0),('physnet1',1207,0),('physnet1',1208,0),('physnet1',1209,0),('physnet1',1210,0),('physnet1',1211,0),('physnet1',1212,0),('physnet1',1213,0),('physnet1',1214,0),('physnet1',1215,0),('physnet1',1216,0),('physnet1',1217,0),('physnet1',1218,0),('physnet1',1219,0),('physnet1',1220,0),('physnet1',1221,0),('physnet1',1222,0),('physnet1',1223,0),('physnet1',1224,0),('physnet1',1225,0),('physnet1',1226,0),('physnet1',1227,0),('physnet1',1228,0),('physnet1',1229,0),('physnet1',1230,0),('physnet1',1231,0),('physnet1',1232,0),('physnet1',1233,0),('physnet1',1234,0),('physnet1',1235,0),('physnet1',1236,0),('physnet1',1237,0),('physnet1',1238,0),('physnet1',1239,0),('physnet1',1240,0),('physnet1',1241,0),('physnet1',1242,0),('physnet1',1243,0),('physnet1',1244,0),('physnet1',1245,0),('physnet1',1246,0),('physnet1',1247,0),('physnet1',1248,0),('physnet1',1249,0),('physnet1',1250,0),('physnet1',1251,0),('physnet1',1252,0),('physnet1',1253,0),('physnet1',1254,0),('physnet1',1255,0),('physnet1',1256,0),('physnet1',1257,0),('physnet1',1258,0),('physnet1',1259,0),('physnet1',1260,0),('physnet1',1261,0),('physnet1',1262,0),('physnet1',1263,0),('physnet1',1264,0),('physnet1',1265,0),('physnet1',1266,0),('physnet1',1267,0),('physnet1',1268,0),('physnet1',1269,0),('physnet1',1270,0),('physnet1',1271,0),('physnet1',1272,0),('physnet1',1273,0),('physnet1',1274,0),('physnet1',1275,0),('physnet1',1276,0),('physnet1',1277,0),('physnet1',1278,0),('physnet1',1279,0),('physnet1',1280,0),('physnet1',1281,0),('physnet1',1282,0),('physnet1',1283,0),('physnet1',1284,0),('physnet1',1285,0),('physnet1',1286,0),('physnet1',1287,0),('physnet1',1288,0),('physnet1',1289,0),('physnet1',1290,0),('physnet1',1291,0),('physnet1',1292,0),('physnet1',1293,0),('physnet1',1294,0),('physnet1',1295,0),('physnet1',1296,0),('physnet1',1297,0),('physnet1',1298,0),('physnet1',1299,0),('physnet1',1300,0),('physnet1',1301,0),('physnet1',1302,0),('physnet1',1303,0),('physnet1',1304,0),('physnet1',1305,0),('physnet1',1306,0),('physnet1',1307,0),('physnet1',1308,0),('physnet1',1309,0),('physnet1',1310,0),('physnet1',1311,0),('physnet1',1312,0),('physnet1',1313,0),('physnet1',1314,0),('physnet1',1315,0),('physnet1',1316,0),('physnet1',1317,0),('physnet1',1318,0),('physnet1',1319,0),('physnet1',1320,0),('physnet1',1321,0),('physnet1',1322,0),('physnet1',1323,0),('physnet1',1324,0),('physnet1',1325,0),('physnet1',1326,0),('physnet1',1327,0),('physnet1',1328,0),('physnet1',1329,0),('physnet1',1330,0),('physnet1',1331,0),('physnet1',1332,0),('physnet1',1333,0),('physnet1',1334,0),('physnet1',1335,0),('physnet1',1336,0),('physnet1',1337,0),('physnet1',1338,0),('physnet1',1339,0),('physnet1',1340,0),('physnet1',1341,0),('physnet1',1342,0),('physnet1',1343,0),('physnet1',1344,0),('physnet1',1345,0),('physnet1',1346,0),('physnet1',1347,0),('physnet1',1348,0),('physnet1',1349,0),('physnet1',1350,0),('physnet1',1351,0),('physnet1',1352,0),('physnet1',1353,0),('physnet1',1354,0),('physnet1',1355,0),('physnet1',1356,0),('physnet1',1357,0),('physnet1',1358,0),('physnet1',1359,0),('physnet1',1360,0),('physnet1',1361,0),('physnet1',1362,0),('physnet1',1363,0),('physnet1',1364,0),('physnet1',1365,0),('physnet1',1366,0),('physnet1',1367,0),('physnet1',1368,0),('physnet1',1369,0),('physnet1',1370,0),('physnet1',1371,0),('physnet1',1372,0),('physnet1',1373,0),('physnet1',1374,0),('physnet1',1375,0),('physnet1',1376,0),('physnet1',1377,0),('physnet1',1378,0),('physnet1',1379,0),('physnet1',1380,0),('physnet1',1381,0),('physnet1',1382,0),('physnet1',1383,0),('physnet1',1384,0),('physnet1',1385,0),('physnet1',1386,0),('physnet1',1387,0),('physnet1',1388,0),('physnet1',1389,0),('physnet1',1390,0),('physnet1',1391,0),('physnet1',1392,0),('physnet1',1393,0),('physnet1',1394,0),('physnet1',1395,0),('physnet1',1396,0),('physnet1',1397,0),('physnet1',1398,0),('physnet1',1399,0),('physnet1',1400,0),('physnet1',1401,0),('physnet1',1402,0),('physnet1',1403,0),('physnet1',1404,0),('physnet1',1405,0),('physnet1',1406,0),('physnet1',1407,0),('physnet1',1408,0),('physnet1',1409,0),('physnet1',1410,0),('physnet1',1411,0),('physnet1',1412,0),('physnet1',1413,0),('physnet1',1414,0),('physnet1',1415,0),('physnet1',1416,0),('physnet1',1417,0),('physnet1',1418,0),('physnet1',1419,0),('physnet1',1420,0),('physnet1',1421,0),('physnet1',1422,0),('physnet1',1423,0),('physnet1',1424,0),('physnet1',1425,0),('physnet1',1426,0),('physnet1',1427,0),('physnet1',1428,0),('physnet1',1429,0),('physnet1',1430,0),('physnet1',1431,0),('physnet1',1432,0),('physnet1',1433,0),('physnet1',1434,0),('physnet1',1435,0),('physnet1',1436,0),('physnet1',1437,0),('physnet1',1438,0),('physnet1',1439,0),('physnet1',1440,0),('physnet1',1441,0),('physnet1',1442,0),('physnet1',1443,0),('physnet1',1444,0),('physnet1',1445,0),('physnet1',1446,0),('physnet1',1447,0),('physnet1',1448,0),('physnet1',1449,0),('physnet1',1450,0),('physnet1',1451,0),('physnet1',1452,0),('physnet1',1453,0),('physnet1',1454,0),('physnet1',1455,0),('physnet1',1456,0),('physnet1',1457,0),('physnet1',1458,0),('physnet1',1459,0),('physnet1',1460,0),('physnet1',1461,0),('physnet1',1462,0),('physnet1',1463,0),('physnet1',1464,0),('physnet1',1465,0),('physnet1',1466,0),('physnet1',1467,0),('physnet1',1468,0),('physnet1',1469,0),('physnet1',1470,0),('physnet1',1471,0),('physnet1',1472,0),('physnet1',1473,0),('physnet1',1474,0),('physnet1',1475,0),('physnet1',1476,0),('physnet1',1477,0),('physnet1',1478,0),('physnet1',1479,0),('physnet1',1480,0),('physnet1',1481,0),('physnet1',1482,0),('physnet1',1483,0),('physnet1',1484,0),('physnet1',1485,0),('physnet1',1486,0),('physnet1',1487,0),('physnet1',1488,0),('physnet1',1489,0),('physnet1',1490,0),('physnet1',1491,0),('physnet1',1492,0),('physnet1',1493,0),('physnet1',1494,0),('physnet1',1495,0),('physnet1',1496,0),('physnet1',1497,0),('physnet1',1498,0),('physnet1',1499,0),('physnet1',1500,0),('physnet1',1501,0),('physnet1',1502,0),('physnet1',1503,0),('physnet1',1504,0),('physnet1',1505,0),('physnet1',1506,0),('physnet1',1507,0),('physnet1',1508,0),('physnet1',1509,0),('physnet1',1510,0),('physnet1',1511,0),('physnet1',1512,0),('physnet1',1513,0),('physnet1',1514,0),('physnet1',1515,0),('physnet1',1516,0),('physnet1',1517,0),('physnet1',1518,0),('physnet1',1519,0),('physnet1',1520,0),('physnet1',1521,0),('physnet1',1522,0),('physnet1',1523,0),('physnet1',1524,0),('physnet1',1525,0),('physnet1',1526,0),('physnet1',1527,0),('physnet1',1528,0),('physnet1',1529,0),('physnet1',1530,0),('physnet1',1531,0),('physnet1',1532,0),('physnet1',1533,0),('physnet1',1534,0),('physnet1',1535,0),('physnet1',1536,0),('physnet1',1537,0),('physnet1',1538,0),('physnet1',1539,0),('physnet1',1540,0),('physnet1',1541,0),('physnet1',1542,0),('physnet1',1543,0),('physnet1',1544,0),('physnet1',1545,0),('physnet1',1546,0),('physnet1',1547,0),('physnet1',1548,0),('physnet1',1549,0),('physnet1',1550,0),('physnet1',1551,0),('physnet1',1552,0),('physnet1',1553,0),('physnet1',1554,0),('physnet1',1555,0),('physnet1',1556,0),('physnet1',1557,0),('physnet1',1558,0),('physnet1',1559,0),('physnet1',1560,0),('physnet1',1561,0),('physnet1',1562,0),('physnet1',1563,0),('physnet1',1564,0),('physnet1',1565,0),('physnet1',1566,0),('physnet1',1567,0),('physnet1',1568,0),('physnet1',1569,0),('physnet1',1570,0),('physnet1',1571,0),('physnet1',1572,0),('physnet1',1573,0),('physnet1',1574,0),('physnet1',1575,0),('physnet1',1576,0),('physnet1',1577,0),('physnet1',1578,0),('physnet1',1579,0),('physnet1',1580,0),('physnet1',1581,0),('physnet1',1582,0),('physnet1',1583,0),('physnet1',1584,0),('physnet1',1585,0),('physnet1',1586,0),('physnet1',1587,0),('physnet1',1588,0),('physnet1',1589,0),('physnet1',1590,0),('physnet1',1591,0),('physnet1',1592,0),('physnet1',1593,0),('physnet1',1594,0),('physnet1',1595,0),('physnet1',1596,0),('physnet1',1597,0),('physnet1',1598,0),('physnet1',1599,0),('physnet1',1600,0),('physnet1',1601,0),('physnet1',1602,0),('physnet1',1603,0),('physnet1',1604,0),('physnet1',1605,0),('physnet1',1606,0),('physnet1',1607,0),('physnet1',1608,0),('physnet1',1609,0),('physnet1',1610,0),('physnet1',1611,0),('physnet1',1612,0),('physnet1',1613,0),('physnet1',1614,0),('physnet1',1615,0),('physnet1',1616,0),('physnet1',1617,0),('physnet1',1618,0),('physnet1',1619,0),('physnet1',1620,0),('physnet1',1621,0),('physnet1',1622,0),('physnet1',1623,0),('physnet1',1624,0),('physnet1',1625,0),('physnet1',1626,0),('physnet1',1627,0),('physnet1',1628,0),('physnet1',1629,0),('physnet1',1630,0),('physnet1',1631,0),('physnet1',1632,0),('physnet1',1633,0),('physnet1',1634,0),('physnet1',1635,0),('physnet1',1636,0),('physnet1',1637,0),('physnet1',1638,0),('physnet1',1639,0),('physnet1',1640,0),('physnet1',1641,0),('physnet1',1642,0),('physnet1',1643,0),('physnet1',1644,0),('physnet1',1645,0),('physnet1',1646,0),('physnet1',1647,0),('physnet1',1648,0),('physnet1',1649,0),('physnet1',1650,0),('physnet1',1651,0),('physnet1',1652,0),('physnet1',1653,0),('physnet1',1654,0),('physnet1',1655,0),('physnet1',1656,0),('physnet1',1657,0),('physnet1',1658,0),('physnet1',1659,0),('physnet1',1660,0),('physnet1',1661,0),('physnet1',1662,0),('physnet1',1663,0),('physnet1',1664,0),('physnet1',1665,0),('physnet1',1666,0),('physnet1',1667,0),('physnet1',1668,0),('physnet1',1669,0),('physnet1',1670,0),('physnet1',1671,0),('physnet1',1672,0),('physnet1',1673,0),('physnet1',1674,0),('physnet1',1675,0),('physnet1',1676,0),('physnet1',1677,0),('physnet1',1678,0),('physnet1',1679,0),('physnet1',1680,0),('physnet1',1681,0),('physnet1',1682,0),('physnet1',1683,0),('physnet1',1684,0),('physnet1',1685,0),('physnet1',1686,0),('physnet1',1687,0),('physnet1',1688,0),('physnet1',1689,0),('physnet1',1690,0),('physnet1',1691,0),('physnet1',1692,0),('physnet1',1693,0),('physnet1',1694,0),('physnet1',1695,0),('physnet1',1696,0),('physnet1',1697,0),('physnet1',1698,0),('physnet1',1699,0),('physnet1',1700,0),('physnet1',1701,0),('physnet1',1702,0),('physnet1',1703,0),('physnet1',1704,0),('physnet1',1705,0),('physnet1',1706,0),('physnet1',1707,0),('physnet1',1708,0),('physnet1',1709,0),('physnet1',1710,0),('physnet1',1711,0),('physnet1',1712,0),('physnet1',1713,0),('physnet1',1714,0),('physnet1',1715,0),('physnet1',1716,0),('physnet1',1717,0),('physnet1',1718,0),('physnet1',1719,0),('physnet1',1720,0),('physnet1',1721,0),('physnet1',1722,0),('physnet1',1723,0),('physnet1',1724,0),('physnet1',1725,0),('physnet1',1726,0),('physnet1',1727,0),('physnet1',1728,0),('physnet1',1729,0),('physnet1',1730,0),('physnet1',1731,0),('physnet1',1732,0),('physnet1',1733,0),('physnet1',1734,0),('physnet1',1735,0),('physnet1',1736,0),('physnet1',1737,0),('physnet1',1738,0),('physnet1',1739,0),('physnet1',1740,0),('physnet1',1741,0),('physnet1',1742,0),('physnet1',1743,0),('physnet1',1744,0),('physnet1',1745,0),('physnet1',1746,0),('physnet1',1747,0),('physnet1',1748,0),('physnet1',1749,0),('physnet1',1750,0),('physnet1',1751,0),('physnet1',1752,0),('physnet1',1753,0),('physnet1',1754,0),('physnet1',1755,0),('physnet1',1756,0),('physnet1',1757,0),('physnet1',1758,0),('physnet1',1759,0),('physnet1',1760,0),('physnet1',1761,0),('physnet1',1762,0),('physnet1',1763,0),('physnet1',1764,0),('physnet1',1765,0),('physnet1',1766,0),('physnet1',1767,0),('physnet1',1768,0),('physnet1',1769,0),('physnet1',1770,0),('physnet1',1771,0),('physnet1',1772,0),('physnet1',1773,0),('physnet1',1774,0),('physnet1',1775,0),('physnet1',1776,0),('physnet1',1777,0),('physnet1',1778,0),('physnet1',1779,0),('physnet1',1780,0),('physnet1',1781,0),('physnet1',1782,0),('physnet1',1783,0),('physnet1',1784,0),('physnet1',1785,0),('physnet1',1786,0),('physnet1',1787,0),('physnet1',1788,0),('physnet1',1789,0),('physnet1',1790,0),('physnet1',1791,0),('physnet1',1792,0),('physnet1',1793,0),('physnet1',1794,0),('physnet1',1795,0),('physnet1',1796,0),('physnet1',1797,0),('physnet1',1798,0),('physnet1',1799,0),('physnet1',1800,0),('physnet1',1801,0),('physnet1',1802,0),('physnet1',1803,0),('physnet1',1804,0),('physnet1',1805,0),('physnet1',1806,0),('physnet1',1807,0),('physnet1',1808,0),('physnet1',1809,0),('physnet1',1810,0),('physnet1',1811,0),('physnet1',1812,0),('physnet1',1813,0),('physnet1',1814,0),('physnet1',1815,0),('physnet1',1816,0),('physnet1',1817,0),('physnet1',1818,0),('physnet1',1819,0),('physnet1',1820,0),('physnet1',1821,0),('physnet1',1822,0),('physnet1',1823,0),('physnet1',1824,0),('physnet1',1825,0),('physnet1',1826,0),('physnet1',1827,0),('physnet1',1828,0),('physnet1',1829,0),('physnet1',1830,0),('physnet1',1831,0),('physnet1',1832,0),('physnet1',1833,0),('physnet1',1834,0),('physnet1',1835,0),('physnet1',1836,0),('physnet1',1837,0),('physnet1',1838,0),('physnet1',1839,0),('physnet1',1840,0),('physnet1',1841,0),('physnet1',1842,0),('physnet1',1843,0),('physnet1',1844,0),('physnet1',1845,0),('physnet1',1846,0),('physnet1',1847,0),('physnet1',1848,0),('physnet1',1849,0),('physnet1',1850,0),('physnet1',1851,0),('physnet1',1852,0),('physnet1',1853,0),('physnet1',1854,0),('physnet1',1855,0),('physnet1',1856,0),('physnet1',1857,0),('physnet1',1858,0),('physnet1',1859,0),('physnet1',1860,0),('physnet1',1861,0),('physnet1',1862,0),('physnet1',1863,0),('physnet1',1864,0),('physnet1',1865,0),('physnet1',1866,0),('physnet1',1867,0),('physnet1',1868,0),('physnet1',1869,0),('physnet1',1870,0),('physnet1',1871,0),('physnet1',1872,0),('physnet1',1873,0),('physnet1',1874,0),('physnet1',1875,0),('physnet1',1876,0),('physnet1',1877,0),('physnet1',1878,0),('physnet1',1879,0),('physnet1',1880,0),('physnet1',1881,0),('physnet1',1882,0),('physnet1',1883,0),('physnet1',1884,0),('physnet1',1885,0),('physnet1',1886,0),('physnet1',1887,0),('physnet1',1888,0),('physnet1',1889,0),('physnet1',1890,0),('physnet1',1891,0),('physnet1',1892,0),('physnet1',1893,0),('physnet1',1894,0),('physnet1',1895,0),('physnet1',1896,0),('physnet1',1897,0),('physnet1',1898,0),('physnet1',1899,0),('physnet1',1900,0),('physnet1',1901,0),('physnet1',1902,0),('physnet1',1903,0),('physnet1',1904,0),('physnet1',1905,0),('physnet1',1906,0),('physnet1',1907,0),('physnet1',1908,0),('physnet1',1909,0),('physnet1',1910,0),('physnet1',1911,0),('physnet1',1912,0),('physnet1',1913,0),('physnet1',1914,0),('physnet1',1915,0),('physnet1',1916,0),('physnet1',1917,0),('physnet1',1918,0),('physnet1',1919,0),('physnet1',1920,0),('physnet1',1921,0),('physnet1',1922,0),('physnet1',1923,0),('physnet1',1924,0),('physnet1',1925,0),('physnet1',1926,0),('physnet1',1927,0),('physnet1',1928,0),('physnet1',1929,0),('physnet1',1930,0),('physnet1',1931,0),('physnet1',1932,0),('physnet1',1933,0),('physnet1',1934,0),('physnet1',1935,0),('physnet1',1936,0),('physnet1',1937,0),('physnet1',1938,0),('physnet1',1939,0),('physnet1',1940,0),('physnet1',1941,0),('physnet1',1942,0),('physnet1',1943,0),('physnet1',1944,0),('physnet1',1945,0),('physnet1',1946,0),('physnet1',1947,0),('physnet1',1948,0),('physnet1',1949,0),('physnet1',1950,0),('physnet1',1951,0),('physnet1',1952,0),('physnet1',1953,0),('physnet1',1954,0),('physnet1',1955,0),('physnet1',1956,0),('physnet1',1957,0),('physnet1',1958,0),('physnet1',1959,0),('physnet1',1960,0),('physnet1',1961,0),('physnet1',1962,0),('physnet1',1963,0),('physnet1',1964,0),('physnet1',1965,0),('physnet1',1966,0),('physnet1',1967,0),('physnet1',1968,0),('physnet1',1969,0),('physnet1',1970,0),('physnet1',1971,0),('physnet1',1972,0),('physnet1',1973,0),('physnet1',1974,0),('physnet1',1975,0),('physnet1',1976,0),('physnet1',1977,0),('physnet1',1978,0),('physnet1',1979,0),('physnet1',1980,0),('physnet1',1981,0),('physnet1',1982,0),('physnet1',1983,0),('physnet1',1984,0),('physnet1',1985,0),('physnet1',1986,0),('physnet1',1987,0),('physnet1',1988,0),('physnet1',1989,0),('physnet1',1990,0),('physnet1',1991,0),('physnet1',1992,0),('physnet1',1993,0),('physnet1',1994,0),('physnet1',1995,0),('physnet1',1996,0),('physnet1',1997,0),('physnet1',1998,0),('physnet1',1999,0),('physnet1',2000,0),('physnet1',2001,0),('physnet1',2002,0),('physnet1',2003,0),('physnet1',2004,0),('physnet1',2005,0),('physnet1',2006,0),('physnet1',2007,0),('physnet1',2008,0),('physnet1',2009,0),('physnet1',2010,0),('physnet1',2011,0),('physnet1',2012,0),('physnet1',2013,0),('physnet1',2014,0),('physnet1',2015,0),('physnet1',2016,0),('physnet1',2017,0),('physnet1',2018,0),('physnet1',2019,0),('physnet1',2020,0),('physnet1',2021,0),('physnet1',2022,0),('physnet1',2023,0),('physnet1',2024,0),('physnet1',2025,0),('physnet1',2026,0),('physnet1',2027,0),('physnet1',2028,0),('physnet1',2029,0),('physnet1',2030,0),('physnet1',2031,0),('physnet1',2032,0),('physnet1',2033,0),('physnet1',2034,0),('physnet1',2035,0),('physnet1',2036,0),('physnet1',2037,0),('physnet1',2038,0),('physnet1',2039,0),('physnet1',2040,0),('physnet1',2041,0),('physnet1',2042,0),('physnet1',2043,0),('physnet1',2044,0),('physnet1',2045,0),('physnet1',2046,0),('physnet1',2047,0),('physnet1',2048,0),('physnet1',2049,0),('physnet1',2050,0),('physnet1',2051,0),('physnet1',2052,0),('physnet1',2053,0),('physnet1',2054,0),('physnet1',2055,0),('physnet1',2056,0),('physnet1',2057,0),('physnet1',2058,0),('physnet1',2059,0),('physnet1',2060,0),('physnet1',2061,0),('physnet1',2062,0),('physnet1',2063,0),('physnet1',2064,0),('physnet1',2065,0),('physnet1',2066,0),('physnet1',2067,0),('physnet1',2068,0),('physnet1',2069,0),('physnet1',2070,0),('physnet1',2071,0),('physnet1',2072,0),('physnet1',2073,0),('physnet1',2074,0),('physnet1',2075,0),('physnet1',2076,0),('physnet1',2077,0),('physnet1',2078,0),('physnet1',2079,0),('physnet1',2080,0),('physnet1',2081,0),('physnet1',2082,0),('physnet1',2083,0),('physnet1',2084,0),('physnet1',2085,0),('physnet1',2086,0),('physnet1',2087,0),('physnet1',2088,0),('physnet1',2089,0),('physnet1',2090,0),('physnet1',2091,0),('physnet1',2092,0),('physnet1',2093,0),('physnet1',2094,0),('physnet1',2095,0),('physnet1',2096,0),('physnet1',2097,0),('physnet1',2098,0),('physnet1',2099,0),('physnet1',2100,0),('physnet1',2101,0),('physnet1',2102,0),('physnet1',2103,0),('physnet1',2104,0),('physnet1',2105,0),('physnet1',2106,0),('physnet1',2107,0),('physnet1',2108,0),('physnet1',2109,0),('physnet1',2110,0),('physnet1',2111,0),('physnet1',2112,0),('physnet1',2113,0),('physnet1',2114,0),('physnet1',2115,0),('physnet1',2116,0),('physnet1',2117,0),('physnet1',2118,0),('physnet1',2119,0),('physnet1',2120,0),('physnet1',2121,0),('physnet1',2122,0),('physnet1',2123,0),('physnet1',2124,0),('physnet1',2125,0),('physnet1',2126,0),('physnet1',2127,0),('physnet1',2128,0),('physnet1',2129,0),('physnet1',2130,0),('physnet1',2131,0),('physnet1',2132,0),('physnet1',2133,0),('physnet1',2134,0),('physnet1',2135,0),('physnet1',2136,0),('physnet1',2137,0),('physnet1',2138,0),('physnet1',2139,0),('physnet1',2140,0),('physnet1',2141,0),('physnet1',2142,0),('physnet1',2143,0),('physnet1',2144,0),('physnet1',2145,0),('physnet1',2146,0),('physnet1',2147,0),('physnet1',2148,0),('physnet1',2149,0),('physnet1',2150,0),('physnet1',2151,0),('physnet1',2152,0),('physnet1',2153,0),('physnet1',2154,0),('physnet1',2155,0),('physnet1',2156,0),('physnet1',2157,0),('physnet1',2158,0),('physnet1',2159,0),('physnet1',2160,0),('physnet1',2161,0),('physnet1',2162,0),('physnet1',2163,0),('physnet1',2164,0),('physnet1',2165,0),('physnet1',2166,0),('physnet1',2167,0),('physnet1',2168,0),('physnet1',2169,0),('physnet1',2170,0),('physnet1',2171,0),('physnet1',2172,0),('physnet1',2173,0),('physnet1',2174,0),('physnet1',2175,0),('physnet1',2176,0),('physnet1',2177,0),('physnet1',2178,0),('physnet1',2179,0),('physnet1',2180,0),('physnet1',2181,0),('physnet1',2182,0),('physnet1',2183,0),('physnet1',2184,0),('physnet1',2185,0),('physnet1',2186,0),('physnet1',2187,0),('physnet1',2188,0),('physnet1',2189,0),('physnet1',2190,0),('physnet1',2191,0),('physnet1',2192,0),('physnet1',2193,0),('physnet1',2194,0),('physnet1',2195,0),('physnet1',2196,0),('physnet1',2197,0),('physnet1',2198,0),('physnet1',2199,0),('physnet1',2200,0),('physnet1',2201,0),('physnet1',2202,0),('physnet1',2203,0),('physnet1',2204,0),('physnet1',2205,0),('physnet1',2206,0),('physnet1',2207,0),('physnet1',2208,0),('physnet1',2209,0),('physnet1',2210,0),('physnet1',2211,0),('physnet1',2212,0),('physnet1',2213,0),('physnet1',2214,0),('physnet1',2215,0),('physnet1',2216,0),('physnet1',2217,0),('physnet1',2218,0),('physnet1',2219,0),('physnet1',2220,0),('physnet1',2221,0),('physnet1',2222,0),('physnet1',2223,0),('physnet1',2224,0),('physnet1',2225,0),('physnet1',2226,0),('physnet1',2227,0),('physnet1',2228,0),('physnet1',2229,0),('physnet1',2230,0),('physnet1',2231,0),('physnet1',2232,0),('physnet1',2233,0),('physnet1',2234,0),('physnet1',2235,0),('physnet1',2236,0),('physnet1',2237,0),('physnet1',2238,0),('physnet1',2239,0),('physnet1',2240,0),('physnet1',2241,0),('physnet1',2242,0),('physnet1',2243,0),('physnet1',2244,0),('physnet1',2245,0),('physnet1',2246,0),('physnet1',2247,0),('physnet1',2248,0),('physnet1',2249,0),('physnet1',2250,0),('physnet1',2251,0),('physnet1',2252,0),('physnet1',2253,0),('physnet1',2254,0),('physnet1',2255,0),('physnet1',2256,0),('physnet1',2257,0),('physnet1',2258,0),('physnet1',2259,0),('physnet1',2260,0),('physnet1',2261,0),('physnet1',2262,0),('physnet1',2263,0),('physnet1',2264,0),('physnet1',2265,0),('physnet1',2266,0),('physnet1',2267,0),('physnet1',2268,0),('physnet1',2269,0),('physnet1',2270,0),('physnet1',2271,0),('physnet1',2272,0),('physnet1',2273,0),('physnet1',2274,0),('physnet1',2275,0),('physnet1',2276,0),('physnet1',2277,0),('physnet1',2278,0),('physnet1',2279,0),('physnet1',2280,0),('physnet1',2281,0),('physnet1',2282,0),('physnet1',2283,0),('physnet1',2284,0),('physnet1',2285,0),('physnet1',2286,0),('physnet1',2287,0),('physnet1',2288,0),('physnet1',2289,0),('physnet1',2290,0),('physnet1',2291,0),('physnet1',2292,0),('physnet1',2293,0),('physnet1',2294,0),('physnet1',2295,0),('physnet1',2296,0),('physnet1',2297,0),('physnet1',2298,0),('physnet1',2299,0),('physnet1',2300,0),('physnet1',2301,0),('physnet1',2302,0),('physnet1',2303,0),('physnet1',2304,0),('physnet1',2305,0),('physnet1',2306,0),('physnet1',2307,0),('physnet1',2308,0),('physnet1',2309,0),('physnet1',2310,0),('physnet1',2311,0),('physnet1',2312,0),('physnet1',2313,0),('physnet1',2314,0),('physnet1',2315,0),('physnet1',2316,0),('physnet1',2317,0),('physnet1',2318,0),('physnet1',2319,0),('physnet1',2320,0),('physnet1',2321,0),('physnet1',2322,0),('physnet1',2323,0),('physnet1',2324,0),('physnet1',2325,0),('physnet1',2326,0),('physnet1',2327,0),('physnet1',2328,0),('physnet1',2329,0),('physnet1',2330,0),('physnet1',2331,0),('physnet1',2332,0),('physnet1',2333,0),('physnet1',2334,0),('physnet1',2335,0),('physnet1',2336,0),('physnet1',2337,0),('physnet1',2338,0),('physnet1',2339,0),('physnet1',2340,0),('physnet1',2341,0),('physnet1',2342,0),('physnet1',2343,0),('physnet1',2344,0),('physnet1',2345,0),('physnet1',2346,0),('physnet1',2347,0),('physnet1',2348,0),('physnet1',2349,0),('physnet1',2350,0),('physnet1',2351,0),('physnet1',2352,0),('physnet1',2353,0),('physnet1',2354,0),('physnet1',2355,0),('physnet1',2356,0),('physnet1',2357,0),('physnet1',2358,0),('physnet1',2359,0),('physnet1',2360,0),('physnet1',2361,0),('physnet1',2362,0),('physnet1',2363,0),('physnet1',2364,0),('physnet1',2365,0),('physnet1',2366,0),('physnet1',2367,0),('physnet1',2368,0),('physnet1',2369,0),('physnet1',2370,0),('physnet1',2371,0),('physnet1',2372,0),('physnet1',2373,0),('physnet1',2374,0),('physnet1',2375,0),('physnet1',2376,0),('physnet1',2377,0),('physnet1',2378,0),('physnet1',2379,0),('physnet1',2380,0),('physnet1',2381,0),('physnet1',2382,0),('physnet1',2383,0),('physnet1',2384,0),('physnet1',2385,0),('physnet1',2386,0),('physnet1',2387,0),('physnet1',2388,0),('physnet1',2389,0),('physnet1',2390,0),('physnet1',2391,0),('physnet1',2392,0),('physnet1',2393,0),('physnet1',2394,0),('physnet1',2395,0),('physnet1',2396,0),('physnet1',2397,0),('physnet1',2398,0),('physnet1',2399,0),('physnet1',2400,0),('physnet1',2401,0),('physnet1',2402,0),('physnet1',2403,0),('physnet1',2404,0),('physnet1',2405,0),('physnet1',2406,0),('physnet1',2407,0),('physnet1',2408,0),('physnet1',2409,0),('physnet1',2410,0),('physnet1',2411,0),('physnet1',2412,0),('physnet1',2413,0),('physnet1',2414,0),('physnet1',2415,0),('physnet1',2416,0),('physnet1',2417,0),('physnet1',2418,0),('physnet1',2419,0),('physnet1',2420,0),('physnet1',2421,0),('physnet1',2422,0),('physnet1',2423,0),('physnet1',2424,0),('physnet1',2425,0),('physnet1',2426,0),('physnet1',2427,0),('physnet1',2428,0),('physnet1',2429,0),('physnet1',2430,0),('physnet1',2431,0),('physnet1',2432,0),('physnet1',2433,0),('physnet1',2434,0),('physnet1',2435,0),('physnet1',2436,0),('physnet1',2437,0),('physnet1',2438,0),('physnet1',2439,0),('physnet1',2440,0),('physnet1',2441,0),('physnet1',2442,0),('physnet1',2443,0),('physnet1',2444,0),('physnet1',2445,0),('physnet1',2446,0),('physnet1',2447,0),('physnet1',2448,0),('physnet1',2449,0),('physnet1',2450,0),('physnet1',2451,0),('physnet1',2452,0),('physnet1',2453,0),('physnet1',2454,0),('physnet1',2455,0),('physnet1',2456,0),('physnet1',2457,0),('physnet1',2458,0),('physnet1',2459,0),('physnet1',2460,0),('physnet1',2461,0),('physnet1',2462,0),('physnet1',2463,0),('physnet1',2464,0),('physnet1',2465,0),('physnet1',2466,0),('physnet1',2467,0),('physnet1',2468,0),('physnet1',2469,0),('physnet1',2470,0),('physnet1',2471,0),('physnet1',2472,0),('physnet1',2473,0),('physnet1',2474,0),('physnet1',2475,0),('physnet1',2476,0),('physnet1',2477,0),('physnet1',2478,0),('physnet1',2479,0),('physnet1',2480,0),('physnet1',2481,0),('physnet1',2482,0),('physnet1',2483,0),('physnet1',2484,0),('physnet1',2485,0),('physnet1',2486,0),('physnet1',2487,0),('physnet1',2488,0),('physnet1',2489,0),('physnet1',2490,0),('physnet1',2491,0),('physnet1',2492,0),('physnet1',2493,0),('physnet1',2494,0),('physnet1',2495,0),('physnet1',2496,0),('physnet1',2497,0),('physnet1',2498,0),('physnet1',2499,0),('physnet1',2500,0),('physnet1',2501,0),('physnet1',2502,0),('physnet1',2503,0),('physnet1',2504,0),('physnet1',2505,0),('physnet1',2506,0),('physnet1',2507,0),('physnet1',2508,0),('physnet1',2509,0),('physnet1',2510,0),('physnet1',2511,0),('physnet1',2512,0),('physnet1',2513,0),('physnet1',2514,0),('physnet1',2515,0),('physnet1',2516,0),('physnet1',2517,0),('physnet1',2518,0),('physnet1',2519,0),('physnet1',2520,0),('physnet1',2521,0),('physnet1',2522,0),('physnet1',2523,0),('physnet1',2524,0),('physnet1',2525,0),('physnet1',2526,0),('physnet1',2527,0),('physnet1',2528,0),('physnet1',2529,0),('physnet1',2530,0),('physnet1',2531,0),('physnet1',2532,0),('physnet1',2533,0),('physnet1',2534,0),('physnet1',2535,0),('physnet1',2536,0),('physnet1',2537,0),('physnet1',2538,0),('physnet1',2539,0),('physnet1',2540,0),('physnet1',2541,0),('physnet1',2542,0),('physnet1',2543,0),('physnet1',2544,0),('physnet1',2545,0),('physnet1',2546,0),('physnet1',2547,0),('physnet1',2548,0),('physnet1',2549,0),('physnet1',2550,0),('physnet1',2551,0),('physnet1',2552,0),('physnet1',2553,0),('physnet1',2554,0),('physnet1',2555,0),('physnet1',2556,0),('physnet1',2557,0),('physnet1',2558,0),('physnet1',2559,0),('physnet1',2560,0),('physnet1',2561,0),('physnet1',2562,0),('physnet1',2563,0),('physnet1',2564,0),('physnet1',2565,0),('physnet1',2566,0),('physnet1',2567,0),('physnet1',2568,0),('physnet1',2569,0),('physnet1',2570,0),('physnet1',2571,0),('physnet1',2572,0),('physnet1',2573,0),('physnet1',2574,0),('physnet1',2575,0),('physnet1',2576,0),('physnet1',2577,0),('physnet1',2578,0),('physnet1',2579,0),('physnet1',2580,0),('physnet1',2581,0),('physnet1',2582,0),('physnet1',2583,0),('physnet1',2584,0),('physnet1',2585,0),('physnet1',2586,0),('physnet1',2587,0),('physnet1',2588,0),('physnet1',2589,0),('physnet1',2590,0),('physnet1',2591,0),('physnet1',2592,0),('physnet1',2593,0),('physnet1',2594,0),('physnet1',2595,0),('physnet1',2596,0),('physnet1',2597,0),('physnet1',2598,0),('physnet1',2599,0),('physnet1',2600,0),('physnet1',2601,0),('physnet1',2602,0),('physnet1',2603,0),('physnet1',2604,0),('physnet1',2605,0),('physnet1',2606,0),('physnet1',2607,0),('physnet1',2608,0),('physnet1',2609,0),('physnet1',2610,0),('physnet1',2611,0),('physnet1',2612,0),('physnet1',2613,0),('physnet1',2614,0),('physnet1',2615,0),('physnet1',2616,0),('physnet1',2617,0),('physnet1',2618,0),('physnet1',2619,0),('physnet1',2620,0),('physnet1',2621,0),('physnet1',2622,0),('physnet1',2623,0),('physnet1',2624,0),('physnet1',2625,0),('physnet1',2626,0),('physnet1',2627,0),('physnet1',2628,0),('physnet1',2629,0),('physnet1',2630,0),('physnet1',2631,0),('physnet1',2632,0),('physnet1',2633,0),('physnet1',2634,0),('physnet1',2635,0),('physnet1',2636,0),('physnet1',2637,0),('physnet1',2638,0),('physnet1',2639,0),('physnet1',2640,0),('physnet1',2641,0),('physnet1',2642,0),('physnet1',2643,0),('physnet1',2644,0),('physnet1',2645,0),('physnet1',2646,0),('physnet1',2647,0),('physnet1',2648,0),('physnet1',2649,0),('physnet1',2650,0),('physnet1',2651,0),('physnet1',2652,0),('physnet1',2653,0),('physnet1',2654,0),('physnet1',2655,0),('physnet1',2656,0),('physnet1',2657,0),('physnet1',2658,0),('physnet1',2659,0),('physnet1',2660,0),('physnet1',2661,0),('physnet1',2662,0),('physnet1',2663,0),('physnet1',2664,0),('physnet1',2665,0),('physnet1',2666,0),('physnet1',2667,0),('physnet1',2668,0),('physnet1',2669,0),('physnet1',2670,0),('physnet1',2671,0),('physnet1',2672,0),('physnet1',2673,0),('physnet1',2674,0),('physnet1',2675,0),('physnet1',2676,0),('physnet1',2677,0),('physnet1',2678,0),('physnet1',2679,0),('physnet1',2680,0),('physnet1',2681,0),('physnet1',2682,0),('physnet1',2683,0),('physnet1',2684,0),('physnet1',2685,0),('physnet1',2686,0),('physnet1',2687,0),('physnet1',2688,0),('physnet1',2689,0),('physnet1',2690,0),('physnet1',2691,0),('physnet1',2692,0),('physnet1',2693,0),('physnet1',2694,0),('physnet1',2695,0),('physnet1',2696,0),('physnet1',2697,0),('physnet1',2698,0),('physnet1',2699,0),('physnet1',2700,0),('physnet1',2701,0),('physnet1',2702,0),('physnet1',2703,0),('physnet1',2704,0),('physnet1',2705,0),('physnet1',2706,0),('physnet1',2707,0),('physnet1',2708,0),('physnet1',2709,0),('physnet1',2710,0),('physnet1',2711,0),('physnet1',2712,0),('physnet1',2713,0),('physnet1',2714,0),('physnet1',2715,0),('physnet1',2716,0),('physnet1',2717,0),('physnet1',2718,0),('physnet1',2719,0),('physnet1',2720,0),('physnet1',2721,0),('physnet1',2722,0),('physnet1',2723,0),('physnet1',2724,0),('physnet1',2725,0),('physnet1',2726,0),('physnet1',2727,0),('physnet1',2728,0),('physnet1',2729,0),('physnet1',2730,0),('physnet1',2731,0),('physnet1',2732,0),('physnet1',2733,0),('physnet1',2734,0),('physnet1',2735,0),('physnet1',2736,0),('physnet1',2737,0),('physnet1',2738,0),('physnet1',2739,0),('physnet1',2740,0),('physnet1',2741,0),('physnet1',2742,0),('physnet1',2743,0),('physnet1',2744,0),('physnet1',2745,0),('physnet1',2746,0),('physnet1',2747,0),('physnet1',2748,0),('physnet1',2749,0),('physnet1',2750,0),('physnet1',2751,0),('physnet1',2752,0),('physnet1',2753,0),('physnet1',2754,0),('physnet1',2755,0),('physnet1',2756,0),('physnet1',2757,0),('physnet1',2758,0),('physnet1',2759,0),('physnet1',2760,0),('physnet1',2761,0),('physnet1',2762,0),('physnet1',2763,0),('physnet1',2764,0),('physnet1',2765,0),('physnet1',2766,0),('physnet1',2767,0),('physnet1',2768,0),('physnet1',2769,0),('physnet1',2770,0),('physnet1',2771,0),('physnet1',2772,0),('physnet1',2773,0),('physnet1',2774,0),('physnet1',2775,0),('physnet1',2776,0),('physnet1',2777,0),('physnet1',2778,0),('physnet1',2779,0),('physnet1',2780,0),('physnet1',2781,0),('physnet1',2782,0),('physnet1',2783,0),('physnet1',2784,0),('physnet1',2785,0),('physnet1',2786,0),('physnet1',2787,0),('physnet1',2788,0),('physnet1',2789,0),('physnet1',2790,0),('physnet1',2791,0),('physnet1',2792,0),('physnet1',2793,0),('physnet1',2794,0),('physnet1',2795,0),('physnet1',2796,0),('physnet1',2797,0),('physnet1',2798,0),('physnet1',2799,0),('physnet1',2800,0),('physnet1',2801,0),('physnet1',2802,0),('physnet1',2803,0),('physnet1',2804,0),('physnet1',2805,0),('physnet1',2806,0),('physnet1',2807,0),('physnet1',2808,0),('physnet1',2809,0),('physnet1',2810,0),('physnet1',2811,0),('physnet1',2812,0),('physnet1',2813,0),('physnet1',2814,0),('physnet1',2815,0),('physnet1',2816,0),('physnet1',2817,0),('physnet1',2818,0),('physnet1',2819,0),('physnet1',2820,0),('physnet1',2821,0),('physnet1',2822,0),('physnet1',2823,0),('physnet1',2824,0),('physnet1',2825,0),('physnet1',2826,0),('physnet1',2827,0),('physnet1',2828,0),('physnet1',2829,0),('physnet1',2830,0),('physnet1',2831,0),('physnet1',2832,0),('physnet1',2833,0),('physnet1',2834,0),('physnet1',2835,0),('physnet1',2836,0),('physnet1',2837,0),('physnet1',2838,0),('physnet1',2839,0),('physnet1',2840,0),('physnet1',2841,0),('physnet1',2842,0),('physnet1',2843,0),('physnet1',2844,0),('physnet1',2845,0),('physnet1',2846,0),('physnet1',2847,0),('physnet1',2848,0),('physnet1',2849,0),('physnet1',2850,0),('physnet1',2851,0),('physnet1',2852,0),('physnet1',2853,0),('physnet1',2854,0),('physnet1',2855,0),('physnet1',2856,0),('physnet1',2857,0),('physnet1',2858,0),('physnet1',2859,0),('physnet1',2860,0),('physnet1',2861,0),('physnet1',2862,0),('physnet1',2863,0),('physnet1',2864,0),('physnet1',2865,0),('physnet1',2866,0),('physnet1',2867,0),('physnet1',2868,0),('physnet1',2869,0),('physnet1',2870,0),('physnet1',2871,0),('physnet1',2872,0),('physnet1',2873,0),('physnet1',2874,0),('physnet1',2875,0),('physnet1',2876,0),('physnet1',2877,0),('physnet1',2878,0),('physnet1',2879,0),('physnet1',2880,0),('physnet1',2881,0),('physnet1',2882,0),('physnet1',2883,0),('physnet1',2884,0),('physnet1',2885,0),('physnet1',2886,0),('physnet1',2887,0),('physnet1',2888,0),('physnet1',2889,0),('physnet1',2890,0),('physnet1',2891,0),('physnet1',2892,0),('physnet1',2893,0),('physnet1',2894,0),('physnet1',2895,0),('physnet1',2896,0),('physnet1',2897,0),('physnet1',2898,0),('physnet1',2899,0),('physnet1',2900,0),('physnet1',2901,0),('physnet1',2902,0),('physnet1',2903,0),('physnet1',2904,0),('physnet1',2905,0),('physnet1',2906,0),('physnet1',2907,0),('physnet1',2908,0),('physnet1',2909,0),('physnet1',2910,0),('physnet1',2911,0),('physnet1',2912,0),('physnet1',2913,0),('physnet1',2914,0),('physnet1',2915,0),('physnet1',2916,0),('physnet1',2917,0),('physnet1',2918,0),('physnet1',2919,0),('physnet1',2920,0),('physnet1',2921,0),('physnet1',2922,0),('physnet1',2923,0),('physnet1',2924,0),('physnet1',2925,0),('physnet1',2926,0),('physnet1',2927,0),('physnet1',2928,0),('physnet1',2929,0),('physnet1',2930,0),('physnet1',2931,0),('physnet1',2932,0),('physnet1',2933,0),('physnet1',2934,0),('physnet1',2935,0),('physnet1',2936,0),('physnet1',2937,0),('physnet1',2938,0),('physnet1',2939,0),('physnet1',2940,0),('physnet1',2941,0),('physnet1',2942,0),('physnet1',2943,0),('physnet1',2944,0),('physnet1',2945,0),('physnet1',2946,0),('physnet1',2947,0),('physnet1',2948,0),('physnet1',2949,0),('physnet1',2950,0),('physnet1',2951,0),('physnet1',2952,0),('physnet1',2953,0),('physnet1',2954,0),('physnet1',2955,0),('physnet1',2956,0),('physnet1',2957,0),('physnet1',2958,0),('physnet1',2959,0),('physnet1',2960,0),('physnet1',2961,0),('physnet1',2962,0),('physnet1',2963,0),('physnet1',2964,0),('physnet1',2965,0),('physnet1',2966,0),('physnet1',2967,0),('physnet1',2968,0),('physnet1',2969,0),('physnet1',2970,0),('physnet1',2971,0),('physnet1',2972,0),('physnet1',2973,0),('physnet1',2974,0),('physnet1',2975,0),('physnet1',2976,0),('physnet1',2977,0),('physnet1',2978,0),('physnet1',2979,0),('physnet1',2980,0),('physnet1',2981,0),('physnet1',2982,0),('physnet1',2983,0),('physnet1',2984,0),('physnet1',2985,0),('physnet1',2986,0),('physnet1',2987,0),('physnet1',2988,0),('physnet1',2989,0),('physnet1',2990,0),('physnet1',2991,0),('physnet1',2992,0),('physnet1',2993,0),('physnet1',2994,0),('physnet1',2995,0),('physnet1',2996,0),('physnet1',2997,0),('physnet1',2998,0),('physnet1',2999,0),('physnet1',3000,0),('physnet1',3001,0),('physnet1',3002,0),('physnet1',3003,0),('physnet1',3004,0),('physnet1',3005,0),('physnet1',3006,0),('physnet1',3007,0),('physnet1',3008,0),('physnet1',3009,0),('physnet1',3010,0),('physnet1',3011,0),('physnet1',3012,0),('physnet1',3013,0),('physnet1',3014,0),('physnet1',3015,0),('physnet1',3016,0),('physnet1',3017,0),('physnet1',3018,0),('physnet1',3019,0),('physnet1',3020,0),('physnet1',3021,0),('physnet1',3022,0),('physnet1',3023,0),('physnet1',3024,0),('physnet1',3025,0),('physnet1',3026,0),('physnet1',3027,0),('physnet1',3028,0),('physnet1',3029,0),('physnet1',3030,0),('physnet1',3031,0),('physnet1',3032,0),('physnet1',3033,0),('physnet1',3034,0),('physnet1',3035,0),('physnet1',3036,0),('physnet1',3037,0),('physnet1',3038,0),('physnet1',3039,0),('physnet1',3040,0),('physnet1',3041,0),('physnet1',3042,0),('physnet1',3043,0),('physnet1',3044,0),('physnet1',3045,0),('physnet1',3046,0),('physnet1',3047,0),('physnet1',3048,0),('physnet1',3049,0),('physnet1',3050,0),('physnet1',3051,0),('physnet1',3052,0),('physnet1',3053,0),('physnet1',3054,0),('physnet1',3055,0),('physnet1',3056,0),('physnet1',3057,0),('physnet1',3058,0),('physnet1',3059,0),('physnet1',3060,0),('physnet1',3061,0),('physnet1',3062,0),('physnet1',3063,0),('physnet1',3064,0),('physnet1',3065,0),('physnet1',3066,0),('physnet1',3067,0),('physnet1',3068,0),('physnet1',3069,0),('physnet1',3070,0),('physnet1',3071,0),('physnet1',3072,0),('physnet1',3073,0),('physnet1',3074,0),('physnet1',3075,0),('physnet1',3076,0),('physnet1',3077,0),('physnet1',3078,0),('physnet1',3079,0),('physnet1',3080,0),('physnet1',3081,0),('physnet1',3082,0),('physnet1',3083,0),('physnet1',3084,0),('physnet1',3085,0),('physnet1',3086,0),('physnet1',3087,0),('physnet1',3088,0),('physnet1',3089,0),('physnet1',3090,0),('physnet1',3091,0),('physnet1',3092,0),('physnet1',3093,0),('physnet1',3094,0),('physnet1',3095,0),('physnet1',3096,0),('physnet1',3097,0),('physnet1',3098,0),('physnet1',3099,0),('physnet1',3100,0),('physnet1',3101,0),('physnet1',3102,0),('physnet1',3103,0),('physnet1',3104,0),('physnet1',3105,0),('physnet1',3106,0),('physnet1',3107,0),('physnet1',3108,0),('physnet1',3109,0),('physnet1',3110,0),('physnet1',3111,0),('physnet1',3112,0),('physnet1',3113,0),('physnet1',3114,0),('physnet1',3115,0),('physnet1',3116,0),('physnet1',3117,0),('physnet1',3118,0),('physnet1',3119,0),('physnet1',3120,0),('physnet1',3121,0),('physnet1',3122,0),('physnet1',3123,0),('physnet1',3124,0),('physnet1',3125,0),('physnet1',3126,0),('physnet1',3127,0),('physnet1',3128,0),('physnet1',3129,0),('physnet1',3130,0),('physnet1',3131,0),('physnet1',3132,0),('physnet1',3133,0),('physnet1',3134,0),('physnet1',3135,0),('physnet1',3136,0),('physnet1',3137,0),('physnet1',3138,0),('physnet1',3139,0),('physnet1',3140,0),('physnet1',3141,0),('physnet1',3142,0),('physnet1',3143,0),('physnet1',3144,0),('physnet1',3145,0),('physnet1',3146,0),('physnet1',3147,0),('physnet1',3148,0),('physnet1',3149,0),('physnet1',3150,0),('physnet1',3151,0),('physnet1',3152,0),('physnet1',3153,0),('physnet1',3154,0),('physnet1',3155,0),('physnet1',3156,0),('physnet1',3157,0),('physnet1',3158,0),('physnet1',3159,0),('physnet1',3160,0),('physnet1',3161,0),('physnet1',3162,0),('physnet1',3163,0),('physnet1',3164,0),('physnet1',3165,0),('physnet1',3166,0),('physnet1',3167,0),('physnet1',3168,0),('physnet1',3169,0),('physnet1',3170,0),('physnet1',3171,0),('physnet1',3172,0),('physnet1',3173,0),('physnet1',3174,0),('physnet1',3175,0),('physnet1',3176,0),('physnet1',3177,0),('physnet1',3178,0),('physnet1',3179,0),('physnet1',3180,0),('physnet1',3181,0),('physnet1',3182,0),('physnet1',3183,0),('physnet1',3184,0),('physnet1',3185,0),('physnet1',3186,0),('physnet1',3187,0),('physnet1',3188,0),('physnet1',3189,0),('physnet1',3190,0),('physnet1',3191,0),('physnet1',3192,0),('physnet1',3193,0),('physnet1',3194,0),('physnet1',3195,0),('physnet1',3196,0),('physnet1',3197,0),('physnet1',3198,0),('physnet1',3199,0),('physnet1',3200,0),('physnet1',3201,0),('physnet1',3202,0),('physnet1',3203,0),('physnet1',3204,0),('physnet1',3205,0),('physnet1',3206,0),('physnet1',3207,0),('physnet1',3208,0),('physnet1',3209,0),('physnet1',3210,0),('physnet1',3211,0),('physnet1',3212,0),('physnet1',3213,0),('physnet1',3214,0),('physnet1',3215,0),('physnet1',3216,0),('physnet1',3217,0),('physnet1',3218,0),('physnet1',3219,0),('physnet1',3220,0),('physnet1',3221,0),('physnet1',3222,0),('physnet1',3223,0),('physnet1',3224,0),('physnet1',3225,0),('physnet1',3226,0),('physnet1',3227,0),('physnet1',3228,0),('physnet1',3229,0),('physnet1',3230,0),('physnet1',3231,0),('physnet1',3232,0),('physnet1',3233,0),('physnet1',3234,0),('physnet1',3235,0),('physnet1',3236,0),('physnet1',3237,0),('physnet1',3238,0),('physnet1',3239,0),('physnet1',3240,0),('physnet1',3241,0),('physnet1',3242,0),('physnet1',3243,0),('physnet1',3244,0),('physnet1',3245,0),('physnet1',3246,0),('physnet1',3247,0),('physnet1',3248,0),('physnet1',3249,0),('physnet1',3250,0),('physnet1',3251,0),('physnet1',3252,0),('physnet1',3253,0),('physnet1',3254,0),('physnet1',3255,0),('physnet1',3256,0),('physnet1',3257,0),('physnet1',3258,0),('physnet1',3259,0),('physnet1',3260,0),('physnet1',3261,0),('physnet1',3262,0),('physnet1',3263,0),('physnet1',3264,0),('physnet1',3265,0),('physnet1',3266,0),('physnet1',3267,0),('physnet1',3268,0),('physnet1',3269,0),('physnet1',3270,0),('physnet1',3271,0),('physnet1',3272,0),('physnet1',3273,0),('physnet1',3274,0),('physnet1',3275,0),('physnet1',3276,0),('physnet1',3277,0),('physnet1',3278,0),('physnet1',3279,0),('physnet1',3280,0),('physnet1',3281,0),('physnet1',3282,0),('physnet1',3283,0),('physnet1',3284,0),('physnet1',3285,0),('physnet1',3286,0),('physnet1',3287,0),('physnet1',3288,0),('physnet1',3289,0),('physnet1',3290,0),('physnet1',3291,0),('physnet1',3292,0),('physnet1',3293,0),('physnet1',3294,0),('physnet1',3295,0),('physnet1',3296,0),('physnet1',3297,0),('physnet1',3298,0),('physnet1',3299,0),('physnet1',3300,0),('physnet1',3301,0),('physnet1',3302,0),('physnet1',3303,0),('physnet1',3304,0),('physnet1',3305,0),('physnet1',3306,0),('physnet1',3307,0),('physnet1',3308,0),('physnet1',3309,0),('physnet1',3310,0),('physnet1',3311,0),('physnet1',3312,0),('physnet1',3313,0),('physnet1',3314,0),('physnet1',3315,0),('physnet1',3316,0),('physnet1',3317,0),('physnet1',3318,0),('physnet1',3319,0),('physnet1',3320,0),('physnet1',3321,0),('physnet1',3322,0),('physnet1',3323,0),('physnet1',3324,0),('physnet1',3325,0),('physnet1',3326,0),('physnet1',3327,0),('physnet1',3328,0),('physnet1',3329,0),('physnet1',3330,0),('physnet1',3331,0),('physnet1',3332,0),('physnet1',3333,0),('physnet1',3334,0),('physnet1',3335,0),('physnet1',3336,0),('physnet1',3337,0),('physnet1',3338,0),('physnet1',3339,0),('physnet1',3340,0),('physnet1',3341,0),('physnet1',3342,0),('physnet1',3343,0),('physnet1',3344,0),('physnet1',3345,0),('physnet1',3346,0),('physnet1',3347,0),('physnet1',3348,0),('physnet1',3349,0),('physnet1',3350,0),('physnet1',3351,0),('physnet1',3352,0),('physnet1',3353,0),('physnet1',3354,0),('physnet1',3355,0),('physnet1',3356,0),('physnet1',3357,0),('physnet1',3358,0),('physnet1',3359,0),('physnet1',3360,0),('physnet1',3361,0),('physnet1',3362,0),('physnet1',3363,0),('physnet1',3364,0),('physnet1',3365,0),('physnet1',3366,0),('physnet1',3367,0),('physnet1',3368,0),('physnet1',3369,0),('physnet1',3370,0),('physnet1',3371,0),('physnet1',3372,0),('physnet1',3373,0),('physnet1',3374,0),('physnet1',3375,0),('physnet1',3376,0),('physnet1',3377,0),('physnet1',3378,0),('physnet1',3379,0),('physnet1',3380,0),('physnet1',3381,0),('physnet1',3382,0),('physnet1',3383,0),('physnet1',3384,0),('physnet1',3385,0),('physnet1',3386,0),('physnet1',3387,0),('physnet1',3388,0),('physnet1',3389,0),('physnet1',3390,0),('physnet1',3391,0),('physnet1',3392,0),('physnet1',3393,0),('physnet1',3394,0),('physnet1',3395,0),('physnet1',3396,0),('physnet1',3397,0),('physnet1',3398,0),('physnet1',3399,0),('physnet1',3400,0),('physnet1',3401,0),('physnet1',3402,0),('physnet1',3403,0),('physnet1',3404,0),('physnet1',3405,0),('physnet1',3406,0),('physnet1',3407,0),('physnet1',3408,0),('physnet1',3409,0),('physnet1',3410,0),('physnet1',3411,0),('physnet1',3412,0),('physnet1',3413,0),('physnet1',3414,0),('physnet1',3415,0),('physnet1',3416,0),('physnet1',3417,0),('physnet1',3418,0),('physnet1',3419,0),('physnet1',3420,0),('physnet1',3421,0),('physnet1',3422,0),('physnet1',3423,0),('physnet1',3424,0),('physnet1',3425,0),('physnet1',3426,0),('physnet1',3427,0),('physnet1',3428,0),('physnet1',3429,0),('physnet1',3430,0),('physnet1',3431,0),('physnet1',3432,0),('physnet1',3433,0),('physnet1',3434,0),('physnet1',3435,0),('physnet1',3436,0),('physnet1',3437,0),('physnet1',3438,0),('physnet1',3439,0),('physnet1',3440,0),('physnet1',3441,0),('physnet1',3442,0),('physnet1',3443,0),('physnet1',3444,0),('physnet1',3445,0),('physnet1',3446,0),('physnet1',3447,0),('physnet1',3448,0),('physnet1',3449,0),('physnet1',3450,0),('physnet1',3451,0),('physnet1',3452,0),('physnet1',3453,0),('physnet1',3454,0),('physnet1',3455,0),('physnet1',3456,0),('physnet1',3457,0),('physnet1',3458,0),('physnet1',3459,0),('physnet1',3460,0),('physnet1',3461,0),('physnet1',3462,0),('physnet1',3463,0),('physnet1',3464,0),('physnet1',3465,0),('physnet1',3466,0),('physnet1',3467,0),('physnet1',3468,0),('physnet1',3469,0),('physnet1',3470,0),('physnet1',3471,0),('physnet1',3472,0),('physnet1',3473,0),('physnet1',3474,0),('physnet1',3475,0),('physnet1',3476,0),('physnet1',3477,0),('physnet1',3478,0),('physnet1',3479,0),('physnet1',3480,0),('physnet1',3481,0),('physnet1',3482,0),('physnet1',3483,0),('physnet1',3484,0),('physnet1',3485,0),('physnet1',3486,0),('physnet1',3487,0),('physnet1',3488,0),('physnet1',3489,0),('physnet1',3490,0),('physnet1',3491,0),('physnet1',3492,0),('physnet1',3493,0),('physnet1',3494,0),('physnet1',3495,0),('physnet1',3496,0),('physnet1',3497,0),('physnet1',3498,0),('physnet1',3499,0),('physnet1',3500,0),('physnet1',3501,0),('physnet1',3502,0),('physnet1',3503,0),('physnet1',3504,0),('physnet1',3505,0),('physnet1',3506,0),('physnet1',3507,0),('physnet1',3508,0),('physnet1',3509,0),('physnet1',3510,0),('physnet1',3511,0),('physnet1',3512,0),('physnet1',3513,0),('physnet1',3514,0),('physnet1',3515,0),('physnet1',3516,0),('physnet1',3517,0),('physnet1',3518,0),('physnet1',3519,0),('physnet1',3520,0),('physnet1',3521,0),('physnet1',3522,0),('physnet1',3523,0),('physnet1',3524,0),('physnet1',3525,0),('physnet1',3526,0),('physnet1',3527,0),('physnet1',3528,0),('physnet1',3529,0),('physnet1',3530,0),('physnet1',3531,0),('physnet1',3532,0),('physnet1',3533,0),('physnet1',3534,0),('physnet1',3535,0),('physnet1',3536,0),('physnet1',3537,0),('physnet1',3538,0),('physnet1',3539,0),('physnet1',3540,0),('physnet1',3541,0),('physnet1',3542,0),('physnet1',3543,0),('physnet1',3544,0),('physnet1',3545,0),('physnet1',3546,0),('physnet1',3547,0),('physnet1',3548,0),('physnet1',3549,0),('physnet1',3550,0),('physnet1',3551,0),('physnet1',3552,0),('physnet1',3553,0),('physnet1',3554,0),('physnet1',3555,0),('physnet1',3556,0),('physnet1',3557,0),('physnet1',3558,0),('physnet1',3559,0),('physnet1',3560,0),('physnet1',3561,0),('physnet1',3562,0),('physnet1',3563,0),('physnet1',3564,0),('physnet1',3565,0),('physnet1',3566,0),('physnet1',3567,0),('physnet1',3568,0),('physnet1',3569,0),('physnet1',3570,0),('physnet1',3571,0),('physnet1',3572,0),('physnet1',3573,0),('physnet1',3574,0),('physnet1',3575,0),('physnet1',3576,0),('physnet1',3577,0),('physnet1',3578,0),('physnet1',3579,0),('physnet1',3580,0),('physnet1',3581,0),('physnet1',3582,0),('physnet1',3583,0),('physnet1',3584,0),('physnet1',3585,0),('physnet1',3586,0),('physnet1',3587,0),('physnet1',3588,0),('physnet1',3589,0),('physnet1',3590,0),('physnet1',3591,0),('physnet1',3592,0),('physnet1',3593,0),('physnet1',3594,0),('physnet1',3595,0),('physnet1',3596,0),('physnet1',3597,0),('physnet1',3598,0),('physnet1',3599,0),('physnet1',3600,0),('physnet1',3601,0),('physnet1',3602,0),('physnet1',3603,0),('physnet1',3604,0),('physnet1',3605,0),('physnet1',3606,0),('physnet1',3607,0),('physnet1',3608,0),('physnet1',3609,0),('physnet1',3610,0),('physnet1',3611,0),('physnet1',3612,0),('physnet1',3613,0),('physnet1',3614,0),('physnet1',3615,0),('physnet1',3616,0),('physnet1',3617,0),('physnet1',3618,0),('physnet1',3619,0),('physnet1',3620,0),('physnet1',3621,0),('physnet1',3622,0),('physnet1',3623,0),('physnet1',3624,0),('physnet1',3625,0),('physnet1',3626,0),('physnet1',3627,0),('physnet1',3628,0),('physnet1',3629,0),('physnet1',3630,0),('physnet1',3631,0),('physnet1',3632,0),('physnet1',3633,0),('physnet1',3634,0),('physnet1',3635,0),('physnet1',3636,0),('physnet1',3637,0),('physnet1',3638,0),('physnet1',3639,0),('physnet1',3640,0),('physnet1',3641,0),('physnet1',3642,0),('physnet1',3643,0),('physnet1',3644,0),('physnet1',3645,0),('physnet1',3646,0),('physnet1',3647,0),('physnet1',3648,0),('physnet1',3649,0),('physnet1',3650,0),('physnet1',3651,0),('physnet1',3652,0),('physnet1',3653,0),('physnet1',3654,0),('physnet1',3655,0),('physnet1',3656,0),('physnet1',3657,0),('physnet1',3658,0),('physnet1',3659,0),('physnet1',3660,0),('physnet1',3661,0),('physnet1',3662,0),('physnet1',3663,0),('physnet1',3664,0),('physnet1',3665,0),('physnet1',3666,0),('physnet1',3667,0),('physnet1',3668,0),('physnet1',3669,0),('physnet1',3670,0),('physnet1',3671,0),('physnet1',3672,0),('physnet1',3673,0),('physnet1',3674,0),('physnet1',3675,0),('physnet1',3676,0),('physnet1',3677,0),('physnet1',3678,0),('physnet1',3679,0),('physnet1',3680,0),('physnet1',3681,0),('physnet1',3682,0),('physnet1',3683,0),('physnet1',3684,0),('physnet1',3685,0),('physnet1',3686,0),('physnet1',3687,0),('physnet1',3688,0),('physnet1',3689,0),('physnet1',3690,0),('physnet1',3691,0),('physnet1',3692,0),('physnet1',3693,0),('physnet1',3694,0),('physnet1',3695,0),('physnet1',3696,0),('physnet1',3697,0),('physnet1',3698,0),('physnet1',3699,0),('physnet1',3700,0),('physnet1',3701,0),('physnet1',3702,0),('physnet1',3703,0),('physnet1',3704,0),('physnet1',3705,0),('physnet1',3706,0),('physnet1',3707,0),('physnet1',3708,0),('physnet1',3709,0),('physnet1',3710,0),('physnet1',3711,0),('physnet1',3712,0),('physnet1',3713,0),('physnet1',3714,0),('physnet1',3715,0),('physnet1',3716,0),('physnet1',3717,0),('physnet1',3718,0),('physnet1',3719,0),('physnet1',3720,0),('physnet1',3721,0),('physnet1',3722,0),('physnet1',3723,0),('physnet1',3724,0),('physnet1',3725,0),('physnet1',3726,0),('physnet1',3727,0),('physnet1',3728,0),('physnet1',3729,0),('physnet1',3730,0),('physnet1',3731,0),('physnet1',3732,0),('physnet1',3733,0),('physnet1',3734,0),('physnet1',3735,0),('physnet1',3736,0),('physnet1',3737,0),('physnet1',3738,0),('physnet1',3739,0),('physnet1',3740,0),('physnet1',3741,0),('physnet1',3742,0),('physnet1',3743,0),('physnet1',3744,0),('physnet1',3745,0),('physnet1',3746,0),('physnet1',3747,0),('physnet1',3748,0),('physnet1',3749,0),('physnet1',3750,0),('physnet1',3751,0),('physnet1',3752,0),('physnet1',3753,0),('physnet1',3754,0),('physnet1',3755,0),('physnet1',3756,0),('physnet1',3757,0),('physnet1',3758,0),('physnet1',3759,0),('physnet1',3760,0),('physnet1',3761,0),('physnet1',3762,0),('physnet1',3763,0),('physnet1',3764,0),('physnet1',3765,0),('physnet1',3766,0),('physnet1',3767,0),('physnet1',3768,0),('physnet1',3769,0),('physnet1',3770,0),('physnet1',3771,0),('physnet1',3772,0),('physnet1',3773,0),('physnet1',3774,0),('physnet1',3775,0),('physnet1',3776,0),('physnet1',3777,0),('physnet1',3778,0),('physnet1',3779,0),('physnet1',3780,0),('physnet1',3781,0),('physnet1',3782,0),('physnet1',3783,0),('physnet1',3784,0),('physnet1',3785,0),('physnet1',3786,0),('physnet1',3787,0),('physnet1',3788,0),('physnet1',3789,0),('physnet1',3790,0),('physnet1',3791,0),('physnet1',3792,0),('physnet1',3793,0),('physnet1',3794,0),('physnet1',3795,0),('physnet1',3796,0),('physnet1',3797,0),('physnet1',3798,0),('physnet1',3799,0),('physnet1',3800,0),('physnet1',3801,0),('physnet1',3802,0),('physnet1',3803,0),('physnet1',3804,0),('physnet1',3805,0),('physnet1',3806,0),('physnet1',3807,0),('physnet1',3808,0),('physnet1',3809,0),('physnet1',3810,0),('physnet1',3811,0),('physnet1',3812,0),('physnet1',3813,0),('physnet1',3814,0),('physnet1',3815,0),('physnet1',3816,0),('physnet1',3817,0),('physnet1',3818,0),('physnet1',3819,0),('physnet1',3820,0),('physnet1',3821,0),('physnet1',3822,0),('physnet1',3823,0),('physnet1',3824,0),('physnet1',3825,0),('physnet1',3826,0),('physnet1',3827,0),('physnet1',3828,0),('physnet1',3829,0),('physnet1',3830,0),('physnet1',3831,0),('physnet1',3832,0),('physnet1',3833,0),('physnet1',3834,0),('physnet1',3835,0),('physnet1',3836,0),('physnet1',3837,0),('physnet1',3838,0),('physnet1',3839,0),('physnet1',3840,0),('physnet1',3841,0),('physnet1',3842,0),('physnet1',3843,0),('physnet1',3844,0),('physnet1',3845,0),('physnet1',3846,0),('physnet1',3847,0),('physnet1',3848,0),('physnet1',3849,0),('physnet1',3850,0),('physnet1',3851,0),('physnet1',3852,0),('physnet1',3853,0),('physnet1',3854,0),('physnet1',3855,0),('physnet1',3856,0),('physnet1',3857,0),('physnet1',3858,0),('physnet1',3859,0),('physnet1',3860,0),('physnet1',3861,0),('physnet1',3862,0),('physnet1',3863,0),('physnet1',3864,0),('physnet1',3865,0),('physnet1',3866,0),('physnet1',3867,0),('physnet1',3868,0),('physnet1',3869,0),('physnet1',3870,0),('physnet1',3871,0),('physnet1',3872,0),('physnet1',3873,0),('physnet1',3874,0),('physnet1',3875,0),('physnet1',3876,0),('physnet1',3877,0),('physnet1',3878,0),('physnet1',3879,0),('physnet1',3880,0),('physnet1',3881,0),('physnet1',3882,0),('physnet1',3883,0),('physnet1',3884,0),('physnet1',3885,0),('physnet1',3886,0),('physnet1',3887,0),('physnet1',3888,0),('physnet1',3889,0),('physnet1',3890,0),('physnet1',3891,0),('physnet1',3892,0),('physnet1',3893,0),('physnet1',3894,0),('physnet1',3895,0),('physnet1',3896,0),('physnet1',3897,0),('physnet1',3898,0),('physnet1',3899,0),('physnet1',3900,0),('physnet1',3901,0),('physnet1',3902,0),('physnet1',3903,0),('physnet1',3904,0),('physnet1',3905,0),('physnet1',3906,0),('physnet1',3907,0),('physnet1',3908,0),('physnet1',3909,0),('physnet1',3910,0),('physnet1',3911,0),('physnet1',3912,0),('physnet1',3913,0),('physnet1',3914,0),('physnet1',3915,0),('physnet1',3916,0),('physnet1',3917,0),('physnet1',3918,0),('physnet1',3919,0),('physnet1',3920,0),('physnet1',3921,0),('physnet1',3922,0),('physnet1',3923,0),('physnet1',3924,0),('physnet1',3925,0),('physnet1',3926,0),('physnet1',3927,0),('physnet1',3928,0),('physnet1',3929,0),('physnet1',3930,0),('physnet1',3931,0),('physnet1',3932,0),('physnet1',3933,0),('physnet1',3934,0),('physnet1',3935,0),('physnet1',3936,0),('physnet1',3937,0),('physnet1',3938,0),('physnet1',3939,0),('physnet1',3940,0),('physnet1',3941,0),('physnet1',3942,0),('physnet1',3943,0),('physnet1',3944,0),('physnet1',3945,0),('physnet1',3946,0),('physnet1',3947,0),('physnet1',3948,0),('physnet1',3949,0),('physnet1',3950,0),('physnet1',3951,0),('physnet1',3952,0),('physnet1',3953,0),('physnet1',3954,0),('physnet1',3955,0),('physnet1',3956,0),('physnet1',3957,0),('physnet1',3958,0),('physnet1',3959,0),('physnet1',3960,0),('physnet1',3961,0),('physnet1',3962,0),('physnet1',3963,0),('physnet1',3964,0),('physnet1',3965,0),('physnet1',3966,0),('physnet1',3967,0),('physnet1',3968,0),('physnet1',3969,0),('physnet1',3970,0),('physnet1',3971,0),('physnet1',3972,0),('physnet1',3973,0),('physnet1',3974,0),('physnet1',3975,0),('physnet1',3976,0),('physnet1',3977,0),('physnet1',3978,0),('physnet1',3979,0),('physnet1',3980,0),('physnet1',3981,0),('physnet1',3982,0),('physnet1',3983,0),('physnet1',3984,0),('physnet1',3985,0),('physnet1',3986,0),('physnet1',3987,0),('physnet1',3988,0),('physnet1',3989,0),('physnet1',3990,0),('physnet1',3991,0),('physnet1',3992,0),('physnet1',3993,0),('physnet1',3994,0),('physnet1',3995,0),('physnet1',3996,0),('physnet1',3997,0),('physnet1',3998,0),('physnet1',3999,0),('physnet1',4000,0),('physnet1',4001,0),('physnet1',4002,0),('physnet1',4003,0),('physnet1',4004,0),('physnet1',4005,0),('physnet1',4006,0),('physnet1',4007,0),('physnet1',4008,0),('physnet1',4009,0),('physnet1',4010,0),('physnet1',4011,0),('physnet1',4012,0),('physnet1',4013,0),('physnet1',4014,0),('physnet1',4015,0),('physnet1',4016,0),('physnet1',4017,0),('physnet1',4018,0),('physnet1',4019,0),('physnet1',4020,0),('physnet1',4021,0),('physnet1',4022,0),('physnet1',4023,0),('physnet1',4024,0),('physnet1',4025,0),('physnet1',4026,0),('physnet1',4027,0),('physnet1',4028,0),('physnet1',4029,0),('physnet1',4030,0),('physnet1',4031,0),('physnet1',4032,0),('physnet1',4033,0),('physnet1',4034,0),('physnet1',4035,0),('physnet1',4036,0),('physnet1',4037,0),('physnet1',4038,0),('physnet1',4039,0),('physnet1',4040,0),('physnet1',4041,0),('physnet1',4042,0),('physnet1',4043,0),('physnet1',4044,0),('physnet1',4045,0),('physnet1',4046,0),('physnet1',4047,0),('physnet1',4048,0),('physnet1',4049,0),('physnet1',4050,0),('physnet1',4051,0),('physnet1',4052,0),('physnet1',4053,0),('physnet1',4054,0),('physnet1',4055,0),('physnet1',4056,0),('physnet1',4057,0),('physnet1',4058,0),('physnet1',4059,0),('physnet1',4060,0),('physnet1',4061,0),('physnet1',4062,0),('physnet1',4063,0),('physnet1',4064,0),('physnet1',4065,0),('physnet1',4066,0),('physnet1',4067,0),('physnet1',4068,0),('physnet1',4069,0),('physnet1',4070,0),('physnet1',4071,0),('physnet1',4072,0),('physnet1',4073,0),('physnet1',4074,0),('physnet1',4075,0),('physnet1',4076,0),('physnet1',4077,0),('physnet1',4078,0),('physnet1',4079,0),('physnet1',4080,0),('physnet1',4081,0),('physnet1',4082,0),('physnet1',4083,0),('physnet1',4084,0),('physnet1',4085,0),('physnet1',4086,0),('physnet1',4087,0),('physnet1',4088,0),('physnet1',4089,0),('physnet1',4090,0),('physnet1',4091,0),('physnet1',4092,0),('physnet1',4093,0),('physnet1',4094,0);
/*!40000 ALTER TABLE `ml2_vlan_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_vxlan_allocations`
--

DROP TABLE IF EXISTS `ml2_vxlan_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_vxlan_allocations` (
  `vxlan_vni` int(11) NOT NULL,
  `allocated` tinyint(1) NOT NULL,
  PRIMARY KEY (`vxlan_vni`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_vxlan_allocations`
--

LOCK TABLES `ml2_vxlan_allocations` WRITE;
/*!40000 ALTER TABLE `ml2_vxlan_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_vxlan_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ml2_vxlan_endpoints`
--

DROP TABLE IF EXISTS `ml2_vxlan_endpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ml2_vxlan_endpoints` (
  `ip_address` varchar(64) NOT NULL DEFAULT '',
  `udp_port` int(11) NOT NULL,
  PRIMARY KEY (`ip_address`,`udp_port`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ml2_vxlan_endpoints`
--

LOCK TABLES `ml2_vxlan_endpoints` WRITE;
/*!40000 ALTER TABLE `ml2_vxlan_endpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `ml2_vxlan_endpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networkdhcpagentbindings`
--

DROP TABLE IF EXISTS `networkdhcpagentbindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networkdhcpagentbindings` (
  `network_id` varchar(36) NOT NULL,
  `dhcp_agent_id` varchar(36) NOT NULL,
  PRIMARY KEY (`network_id`,`dhcp_agent_id`),
  KEY `dhcp_agent_id` (`dhcp_agent_id`),
  CONSTRAINT `networkdhcpagentbindings_ibfk_1` FOREIGN KEY (`dhcp_agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `networkdhcpagentbindings_ibfk_2` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networkdhcpagentbindings`
--

LOCK TABLES `networkdhcpagentbindings` WRITE;
/*!40000 ALTER TABLE `networkdhcpagentbindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `networkdhcpagentbindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `networks`
--

DROP TABLE IF EXISTS `networks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `networks` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(16) DEFAULT NULL,
  `admin_state_up` tinyint(1) DEFAULT NULL,
  `shared` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `networks`
--

LOCK TABLES `networks` WRITE;
/*!40000 ALTER TABLE `networks` DISABLE KEYS */;
/*!40000 ALTER TABLE `networks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ports`
--

DROP TABLE IF EXISTS `ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ports` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `network_id` varchar(36) NOT NULL,
  `mac_address` varchar(32) NOT NULL,
  `admin_state_up` tinyint(1) NOT NULL,
  `status` varchar(16) NOT NULL,
  `device_id` varchar(255) NOT NULL,
  `device_owner` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `network_id` (`network_id`),
  CONSTRAINT `ports_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ports`
--

LOCK TABLES `ports` WRITE;
/*!40000 ALTER TABLE `ports` DISABLE KEYS */;
/*!40000 ALTER TABLE `ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotas`
--

DROP TABLE IF EXISTS `quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotas` (
  `id` varchar(36) NOT NULL,
  `tenant_id` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `limit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_quotas_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotas`
--

LOCK TABLES `quotas` WRITE;
/*!40000 ALTER TABLE `quotas` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routerl3agentbindings`
--

DROP TABLE IF EXISTS `routerl3agentbindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `routerl3agentbindings` (
  `id` varchar(36) NOT NULL,
  `router_id` varchar(36) DEFAULT NULL,
  `l3_agent_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `l3_agent_id` (`l3_agent_id`),
  KEY `router_id` (`router_id`),
  CONSTRAINT `routerl3agentbindings_ibfk_1` FOREIGN KEY (`l3_agent_id`) REFERENCES `agents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `routerl3agentbindings_ibfk_2` FOREIGN KEY (`router_id`) REFERENCES `routers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routerl3agentbindings`
--

LOCK TABLES `routerl3agentbindings` WRITE;
/*!40000 ALTER TABLE `routerl3agentbindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `routerl3agentbindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routerroutes`
--

DROP TABLE IF EXISTS `routerroutes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `routerroutes` (
  `destination` varchar(64) NOT NULL,
  `nexthop` varchar(64) NOT NULL,
  `router_id` varchar(36) NOT NULL,
  PRIMARY KEY (`destination`,`nexthop`,`router_id`),
  KEY `router_id` (`router_id`),
  CONSTRAINT `routerroutes_ibfk_1` FOREIGN KEY (`router_id`) REFERENCES `routers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routerroutes`
--

LOCK TABLES `routerroutes` WRITE;
/*!40000 ALTER TABLE `routerroutes` DISABLE KEYS */;
/*!40000 ALTER TABLE `routerroutes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routers`
--

DROP TABLE IF EXISTS `routers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `routers` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` varchar(16) DEFAULT NULL,
  `admin_state_up` tinyint(1) DEFAULT NULL,
  `gw_port_id` varchar(36) DEFAULT NULL,
  `enable_snat` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gw_port_id` (`gw_port_id`),
  CONSTRAINT `routers_ibfk_1` FOREIGN KEY (`gw_port_id`) REFERENCES `ports` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routers`
--

LOCK TABLES `routers` WRITE;
/*!40000 ALTER TABLE `routers` DISABLE KEYS */;
/*!40000 ALTER TABLE `routers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygroupportbindings`
--

DROP TABLE IF EXISTS `securitygroupportbindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `securitygroupportbindings` (
  `port_id` varchar(36) NOT NULL,
  `security_group_id` varchar(36) NOT NULL,
  PRIMARY KEY (`port_id`,`security_group_id`),
  KEY `security_group_id` (`security_group_id`),
  CONSTRAINT `securitygroupportbindings_ibfk_1` FOREIGN KEY (`port_id`) REFERENCES `ports` (`id`) ON DELETE CASCADE,
  CONSTRAINT `securitygroupportbindings_ibfk_2` FOREIGN KEY (`security_group_id`) REFERENCES `securitygroups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygroupportbindings`
--

LOCK TABLES `securitygroupportbindings` WRITE;
/*!40000 ALTER TABLE `securitygroupportbindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygroupportbindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygrouprules`
--

DROP TABLE IF EXISTS `securitygrouprules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `securitygrouprules` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `security_group_id` varchar(36) NOT NULL,
  `remote_group_id` varchar(36) DEFAULT NULL,
  `direction` enum('ingress','egress') DEFAULT NULL,
  `ethertype` varchar(40) DEFAULT NULL,
  `protocol` varchar(40) DEFAULT NULL,
  `port_range_min` int(11) DEFAULT NULL,
  `port_range_max` int(11) DEFAULT NULL,
  `remote_ip_prefix` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `security_group_id` (`security_group_id`),
  KEY `remote_group_id` (`remote_group_id`),
  CONSTRAINT `securitygrouprules_ibfk_1` FOREIGN KEY (`security_group_id`) REFERENCES `securitygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `securitygrouprules_ibfk_2` FOREIGN KEY (`remote_group_id`) REFERENCES `securitygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygrouprules`
--

LOCK TABLES `securitygrouprules` WRITE;
/*!40000 ALTER TABLE `securitygrouprules` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygrouprules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `securitygroups`
--

DROP TABLE IF EXISTS `securitygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `securitygroups` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `securitygroups`
--

LOCK TABLES `securitygroups` WRITE;
/*!40000 ALTER TABLE `securitygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `securitygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicedefinitions`
--

DROP TABLE IF EXISTS `servicedefinitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicedefinitions` (
  `id` varchar(36) NOT NULL,
  `service_class` varchar(255) NOT NULL,
  `plugin` varchar(255) DEFAULT NULL,
  `driver` varchar(255) DEFAULT NULL,
  `service_type_id` varchar(36) NOT NULL,
  PRIMARY KEY (`id`,`service_class`,`service_type_id`),
  KEY `servicedefinitions_ibfk_1` (`service_type_id`),
  CONSTRAINT `servicedefinitions_ibfk_1` FOREIGN KEY (`service_type_id`) REFERENCES `servicetypes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicedefinitions`
--

LOCK TABLES `servicedefinitions` WRITE;
/*!40000 ALTER TABLE `servicedefinitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicedefinitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicetypes`
--

DROP TABLE IF EXISTS `servicetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicetypes` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL,
  `num_instances` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicetypes`
--

LOCK TABLES `servicetypes` WRITE;
/*!40000 ALTER TABLE `servicetypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `servicetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnetroutes`
--

DROP TABLE IF EXISTS `subnetroutes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subnetroutes` (
  `destination` varchar(64) NOT NULL,
  `nexthop` varchar(64) NOT NULL,
  `subnet_id` varchar(36) NOT NULL,
  PRIMARY KEY (`destination`,`nexthop`,`subnet_id`),
  KEY `subnet_id` (`subnet_id`),
  CONSTRAINT `subnetroutes_ibfk_1` FOREIGN KEY (`subnet_id`) REFERENCES `subnets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnetroutes`
--

LOCK TABLES `subnetroutes` WRITE;
/*!40000 ALTER TABLE `subnetroutes` DISABLE KEYS */;
/*!40000 ALTER TABLE `subnetroutes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subnets`
--

DROP TABLE IF EXISTS `subnets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subnets` (
  `tenant_id` varchar(255) DEFAULT NULL,
  `id` varchar(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `network_id` varchar(36) DEFAULT NULL,
  `ip_version` int(11) NOT NULL,
  `cidr` varchar(64) NOT NULL,
  `gateway_ip` varchar(64) DEFAULT NULL,
  `enable_dhcp` tinyint(1) DEFAULT NULL,
  `shared` tinyint(1) DEFAULT NULL,
  `ipv6_ra_mode` enum('slaac','dhcpv6-stateful','dhcpv6-stateless') DEFAULT NULL,
  `ipv6_address_mode` enum('slaac','dhcpv6-stateful','dhcpv6-stateless') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_id` (`network_id`),
  CONSTRAINT `subnets_ibfk_1` FOREIGN KEY (`network_id`) REFERENCES `networks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subnets`
--

LOCK TABLES `subnets` WRITE;
/*!40000 ALTER TABLE `subnets` DISABLE KEYS */;
/*!40000 ALTER TABLE `subnets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-05-22 22:48:04
